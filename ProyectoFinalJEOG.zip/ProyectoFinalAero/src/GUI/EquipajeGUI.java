package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import Clases.Equipaje;
import Clases.Equipaje.TIENE_MASCOTA;
import Sistema_Embarque.EmbarqueGUI;
import metodos_Aux.Aux_Datos;
import metodos_Aux.Aux_Datos.DataType;
import metodos_Aux.Aux_Datos.OpType;
import metodos_Aux.IObserver;



public class EquipajeGUI extends JPanel implements ActionListener, IObserver<Equipaje> {

	/**
	 * @author janus 
	 * La interfaz pasajero tiene la funcion de obtener los datos del pasajaero para
	 * posteriormente asignarlos al vuelo correspondiente.
	 */
	
	private static final long serialVersionUID = -8762527504926439254L;
	private JPanel formPanel;
	private JTable tableEquipaje;
	private JScrollPane scrollPane;
	private DefaultTableModel tableModelo;
	private Box mainBox;

	private JLabel lblPasajeroID;
	private JLabel lblNomPasajero;
	private JLabel lblpesoPasajero;
	private JLabel lbletiquetaPasj;
	private JLabel lblmascota;

	private JTextField txtPasajeroID;
	private JTextField txtNomPasajero;
	private JTextField txtPesoEQPJ;
	private JTextField txtetiquetaEquipaje;
	private JComboBox<String> cmbMascota;

	private JButton btnGuardarEquipaje;
	private JButton btnBorrarEquipaje;

	private int DEFAULT_WIDTH = 400;
	private int DEFAULT_HEIGHT = 40;

	private JPanel idPanel;
	private JPanel nomPanel;
	private JPanel pesoPanel;
	private JPanel etiquetaPanel;
	private JPanel mascotaPanel;
	private JPanel vueloPanel;
	private JPanel botonPanel;

	private Equipaje equipaje = null;

	/**
	 *  Metodo que inicia la construccion de ventanas..
	 */
	public EquipajeGUI() {
		construirGUI();
	}

	private void construirGUI() {
		setLayout(new GridLayout(1, 2));
		contornoForm();
		inicializarTabla();
		add(formPanel);
		add(scrollPane);
	}

	private void contornoForm() {
		formPanel = new JPanel();
		formPanel.setBorder(BorderFactory.createTitledBorder("Gestion equipaje"));
		formPanel.setLayout(new BorderLayout());

		lblPasajeroID = new JLabel("ID propietario");
		lblNomPasajero = new JLabel("Nombre propietario");
		lblNomPasajero.setBounds(9, 11, 171, 14);
		lblpesoPasajero = new JLabel("Peso equipaje");
		lblpesoPasajero.setBounds(22, 8, 96, 14);
		lbletiquetaPasj = new JLabel("Ticket equipaje");
		lbletiquetaPasj.setBounds(32, 11, 112, 14);
		lblmascota = new JLabel("Viaja con mascota");

		txtPasajeroID = new JTextField(10);
		txtNomPasajero = new JTextField(15);
		txtNomPasajero.setBounds(123, 8, 80, 20);
		txtPesoEQPJ = new JTextField(5);
		txtPesoEQPJ.setBounds(138, 5, 46, 20);
		txtetiquetaEquipaje = new JTextField(15);
		txtetiquetaEquipaje.setBounds(131, 8, 72, 20);

		cmbMascota = new JComboBox<>();
		cmbMascota.addItem("SI");
		cmbMascota.addItem("NO");

		btnGuardarEquipaje = new JButton("A\u00F1adir");
		btnGuardarEquipaje.addActionListener(this);
		btnBorrarEquipaje = new JButton("Borrar");
		btnBorrarEquipaje.addActionListener(this);

		idPanel = new JPanel();
		nomPanel = new JPanel();
		pesoPanel = new JPanel();
		etiquetaPanel = new JPanel();
		mascotaPanel = new JPanel();
		vueloPanel = new JPanel();
		botonPanel = new JPanel();

		idPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		idPanel.setMaximumSize(idPanel.getPreferredSize());
		idPanel.setLayout(new FlowLayout());
		idPanel.add(lblPasajeroID);
		idPanel.add(txtPasajeroID);

		nomPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		nomPanel.setMaximumSize(nomPanel.getPreferredSize());
		nomPanel.setLayout(null);
		nomPanel.add(lblNomPasajero);
		nomPanel.add(txtNomPasajero);

		pesoPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		pesoPanel.setMaximumSize(pesoPanel.getPreferredSize());
		pesoPanel.setLayout(null);
		pesoPanel.add(lblpesoPasajero);
		pesoPanel.add(txtPesoEQPJ);

		etiquetaPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		etiquetaPanel.setMaximumSize(etiquetaPanel.getPreferredSize());
		etiquetaPanel.setLayout(null);
		etiquetaPanel.add(lbletiquetaPasj);
		etiquetaPanel.add(txtetiquetaEquipaje);

		mascotaPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		mascotaPanel.setMaximumSize(mascotaPanel.getPreferredSize());
		mascotaPanel.setLayout(new FlowLayout());
		mascotaPanel.add(lblmascota);
		mascotaPanel.add(cmbMascota);

		botonPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		botonPanel.setMaximumSize(botonPanel.getPreferredSize());
		botonPanel.setLayout(new FlowLayout());
		botonPanel.add(btnGuardarEquipaje);
		botonPanel.add(btnBorrarEquipaje);

		mainBox = Box.createVerticalBox();
		mainBox.add(idPanel);
		mainBox.add(nomPanel);
		mainBox.add(pesoPanel);
		mainBox.add(etiquetaPanel);
		mainBox.add(mascotaPanel);
		mainBox.add(vueloPanel);
		vueloPanel.setLayout(null);
		
		JButton btnNewButton = new JButton("Embarque equipaje");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmbarqueGUI eg = new EmbarqueGUI();
				eg.setVisible(true);
			}
		});
		btnNewButton.setBounds(27, 11, 163, 23);
		vueloPanel.add(btnNewButton);
		mainBox.add(botonPanel);

		formPanel.add(mainBox, BorderLayout.CENTER);
	}

	private void inicializarTabla() {
		Object columnNoms[] = { "ID", "Nombre", "Peso neto", "Etiqueta", "Viaja con mascota" };
		tableModelo = new DefaultTableModel(columnNoms, 0);
		tableEquipaje = new JTable(tableModelo);
		scrollPane = new JScrollPane(tableEquipaje);
		configurarTablaData();
	}

	private void configurarTablaData() {
		tableModelo = (DefaultTableModel) tableEquipaje.getModel();
		tableModelo.setRowCount(0);
		
		LinkedHashMap<String, Equipaje> equipajeMap = Aux_Datos.Instanciar.getList(DataType.EQUIPAJE);
		Iterator<Equipaje> iterator = equipajeMap.values().iterator();
		
		while (iterator.hasNext()) {
			Equipaje equipaje = iterator.next();
			Vector<Object> vector = returnarObjectArray(equipaje);
			tableModelo.addRow(vector);	
			
		}
		tableEquipaje.repaint();
	}

	private Vector<Object> returnarObjectArray(Equipaje equipaje2) {
		Vector<Object> vector = new Vector<>();
		
		vector.add(equipaje2.getIdPersona());
		vector.add(equipaje2.getNombrePersona());
		vector.add(equipaje2.getPesoMale());
		vector.add(equipaje2.getEtiquetaEp());
		vector.add(equipaje2.getMascotaEquipaje());
		return vector;
		
	}
	
	@Override
	public void notificar(Equipaje model, OpType opType) {

			configurarTablaData();
		}
		

	@Override
	public void actionPerformed(ActionEvent e) {
		String pesoText = txtPesoEQPJ.getText();
		int peso = 0;
		try {
			peso = Integer.parseInt(pesoText);
		} catch (NumberFormatException p1) {
			mostrarError("Solo puede ingresar numeros en el peso.");
			return;
		}

		int indiceSeleccionClase = cmbMascota.getSelectedIndex();
		TIENE_MASCOTA pMascota = null;
		switch (indiceSeleccionClase) {
		case 0:
			pMascota = TIENE_MASCOTA.SI;
			break;
		case 1:
			pMascota = TIENE_MASCOTA.NO;
			break;
		default:
			JOptionPane.showMessageDialog(null, "Seleccione una clase", "Error", JOptionPane.INFORMATION_MESSAGE);
			break;
		}

		equipaje = new Equipaje(txtPasajeroID.getText(),txtNomPasajero.getText(), txtetiquetaEquipaje.getText(), peso);
		equipaje.setMascotaEquipaje(pMascota);
		equipaje.agregarObserver(this);

		if (e.getSource() == btnGuardarEquipaje) {
			String result = validarControles(Aux_Datos.OpType.INSERTAR);
			if (result != null) {
				mostrarError(result);
				return;
			} else {
				boolean poderReservar = true;
				if (poderReservar) {
					guardarIng(OpType.INSERTAR);
				} else {
					mostrarError("Lo sentimos. Usted agrego mas del limite de reservas permitidas");
				}
				// retornar;
			}
		}

		if (e.getSource() == btnBorrarEquipaje) {
			String result = validarControles(Aux_Datos.OpType.BORRAR);
			if (result != null) {
				mostrarError(result);
				return;
			} else {
				borrarRegistro();
				return;
			}
		}
	}

	public void guardarIng(OpType opType) {
		boolean guardado = Aux_Datos.Instanciar.agregarObject(equipaje, equipaje.getIdPersona(), DataType.EQUIPAJE,
				opType);
		if (guardado) {
			JOptionPane.showMessageDialog(formPanel, "Guardado", "HECHO", JOptionPane.INFORMATION_MESSAGE);
			limpiarForm();
		} else {
			JOptionPane.showMessageDialog(formPanel, "No se pudo guardar la data", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void borrarRegistro() {
		boolean eliminado = Aux_Datos.Instanciar.eliminarObject(equipaje.getIdPersona(), DataType.EQUIPAJE);
		if (eliminado) {
			JOptionPane.showMessageDialog(formPanel, "Data eliminada", "HECHO", JOptionPane.INFORMATION_MESSAGE);
			limpiarForm();
		} else {
			JOptionPane.showMessageDialog(formPanel, "No se pudo eliminarla data", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void limpiarForm() {
		txtPasajeroID.setText(null);
		txtNomPasajero.setText(null);
		txtPesoEQPJ.setText(null);
		txtetiquetaEquipaje.setText(null);
		cmbMascota.setSelectedIndex(0);
	}

	private void mostrarError(String message) {
		JOptionPane.showMessageDialog(formPanel, message, "Error de validacion", JOptionPane.ERROR_MESSAGE);
	}

	public String validarControles(OpType opType) {
		String pasajeroID = equipaje.getIdPersona();
		String nomPasajero = equipaje.getNombrePersona();
		int pesoEquipaje = equipaje.getPesoMale();
		String etiquetaEpj = equipaje.getEtiquetaEp();
		TIENE_MASCOTA mascotaEpj = equipaje.getMascotaEquipaje();
		
		if (pasajeroID.length() <=0) {
			return "La ID no puede estar vacia.";
		}
		if (nomPasajero.length() <=0 && opType != OpType.BORRAR) {
			return "Debe ingresar el nombre del pasajero asignado al equipaje.";
		}
		
		if (pesoEquipaje < 1 && opType == OpType.BORRAR) {
			return "Peso ingresado incorrectamente";
		}
		if (pesoEquipaje <= 33) {
			JOptionPane.showMessageDialog(pesoPanel, "No debe pagar costo adicional");
		}
		if (pesoEquipaje >= 34) {
			JOptionPane.showMessageDialog(pesoPanel, "Debera pagar una suma adicional de 48 dolares.");
		}
		
		if (etiquetaEpj.length() <= 0 && opType != OpType.BORRAR) {
			return "La casilla etiqueta no puede estar vacia";
		}
		
		if (mascotaEpj.toString().length() <= 0) {
			return "Debe indicar si viaja con mascota o no.";
		}
		boolean existe = Aux_Datos.Instanciar.contieneKeys(pasajeroID, Aux_Datos.DataType.EQUIPAJE);
		if (existe && opType == OpType.INSERTAR) {
			return "Pasajero ya registrado en el sistema, no se permite elementos duplicados";
		}

		if (!existe && opType == OpType.BORRAR) {
			return "Lo sentimos, no se pudo guardar.";
		}

		return null;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
	}
	}


