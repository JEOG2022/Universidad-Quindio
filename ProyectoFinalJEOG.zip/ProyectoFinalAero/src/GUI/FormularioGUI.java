package GUI;

import java.awt.CardLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import Sistema_Embarque.EmbarqueGUI;
import metodos_Aux.Aux_Archivos;
import javax.swing.JButton;

public class FormularioGUI extends JFrame implements ActionListener {
	

	private static final long serialVersionUID = 7015622559546720214L;

	private JMenuBar menuBar;
	private JMenu mnCRUD;
	private JMenu mnReserva;
	private JMenu mnGuardar;

	private JMenuItem mntmAerolinea;
	private JMenuItem mntmVuelo;
	private JMenuItem mntmPasajero;
	private JMenuItem mntmReservaPasajero;
	private JMenuItem mntmGuardarData;
	private JMenuItem mntmEquipaje;
	private JMenuItem mntmEmbarque;

	protected AerolineaGUI aerolineaPanel;
	protected VueloGUI vueloPanel;
	protected PasajeroGUI pasajeroPanel;
	protected ReservaGUI reservacionPanel;
	protected EquipajeGUI equipajePanel;
	protected EmbarqueGUI embarquePanel;

	private Container pane = this.getContentPane();
	private CardLayout layout = new CardLayout();

	/**
	 *  Metodo que inicia la construccion de ventanas..
	 */
	public FormularioGUI() {
		setResizable(false);
		setTitle("Proyecto Aeropuerto");
		setSize(850, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(layout);

		menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		mnCRUD = new JMenu("Data");
		mnCRUD.setMnemonic('D');
		menuBar.add(mnCRUD);

		mnReserva = new JMenu("Reservacion");
		mnReserva.setMnemonic('B');
		menuBar.add(mnReserva);

		mnGuardar = new JMenu("Guardar");
		mnGuardar.setMnemonic('G');
		menuBar.add(mnGuardar);

		mntmAerolinea = new JMenuItem("Aerolineas");
		mntmAerolinea.setMnemonic('A');
		mntmAerolinea.addActionListener(this);
		mnCRUD.add(mntmAerolinea);

		mntmVuelo = new JMenuItem("Vuelo");
		mntmVuelo.setMnemonic('V');
		mntmVuelo.addActionListener(this);
		mnCRUD.add(mntmVuelo);

		mntmPasajero = new JMenuItem("Pasajero");
		mntmPasajero.setMnemonic('P');
		mntmPasajero.addActionListener(this);
		mnCRUD.add(mntmPasajero);
		
		mntmEquipaje = new JMenuItem("Equipaje");
		mntmEquipaje.setMnemonic('E');
		mntmEquipaje.addActionListener(this);
		mnCRUD.add(mntmEquipaje);

		mntmReservaPasajero = new JMenuItem("Reservar Pasajero");
		mntmReservaPasajero.setMnemonic('R');
		mntmReservaPasajero.addActionListener(this);
		mnReserva.add(mntmReservaPasajero);

		mntmGuardarData = new JMenuItem("Guardado");
		mntmGuardarData.setMnemonic('T');
		mntmGuardarData.addActionListener(this);
		mnGuardar.add(mntmGuardarData);

		aerolineaPanel = new AerolineaGUI();
		vueloPanel = new VueloGUI();
		pasajeroPanel = new PasajeroGUI();
		reservacionPanel = new ReservaGUI();
		equipajePanel = new EquipajeGUI();


		pane.add("Aerolinea", aerolineaPanel);
		pane.add("Vuelo", vueloPanel);
		pane.add("Pasajero", pasajeroPanel);
		pane.add("Reserva", reservacionPanel);
		pane.add("Equipaje", equipajePanel);


	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == mntmAerolinea) {
			layout.show(pane, "Aerolinea");
		} else if (e.getSource() == mntmVuelo) {
			layout.show(pane, "Vuelo");
		} else if (e.getSource() == mntmPasajero) {
			layout.show(pane, "Pasajero");
		} else if (e.getSource() == mntmReservaPasajero) {
			layout.show(pane, "Reserva");
		} else if (e.getSource() == mntmEquipaje) {
			layout.show(pane, "Equipaje");
			/*
		} else if (e.getSource() == mntmEmbarque) {
			layout.show(pane, "Embarque");
			*/
		} else if (e.getSource() == mntmGuardarData) {
			boolean result = Aux_Archivos.serialize();
			if (result) {
				JOptionPane.showMessageDialog(null, "Guardado correctamente", "Hecho", JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null, "Error al guardar los archivos", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}

}