package GUI;


import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Vector;
import java.awt.FlowLayout;
import java.awt.Graphics;

import javax.swing.table.DefaultTableModel;

import Clases.Aerolinea;
import metodos_Aux.Aux_Datos;
import metodos_Aux.IObserver;
import metodos_Aux.Aux_Datos.DataType;
import metodos_Aux.Aux_Datos.OpType;

import javax.swing.JTable;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Color;

public class AerolineaGUI extends JPanel implements ActionListener, IObserver<Aerolinea> {

	/**
	 * 
	 * Este tipo de llenado de datos se hizo con el fin de gestionar no solo una aerolinea sino varias,
	 * teniendo asi una similitud mas precisa a la realidad, que dando manejo a una sola aerolinea.
	 * 
	 * El tipo de listas de Colecciones que se elijio en este proyecto fueron las LinkedHashmap, debido a su 
	 * dinamismo con el manejo de los datos, ya que resulta mas optimo en la insercion de datos, proporcionando asi
	 * un orden conforme el usuario llena los formularios. 
	 */
	
	private static final long serialVersionUID = -5768781871242697490L;
	private JPanel formPanel;
	private JTable tablaAerolinea;
	private JScrollPane scrollPane;
	private DefaultTableModel tableModel;
	private Box mainBox;

	private JLabel lblCodAerolinea;
	private JLabel lblNomAerolinea;

	private JTextField txtAerolineaCod;
	private JTextField txtNomAerolinea;

	private JButton btnGuardarAerolinea;

	private int DEFAULT_WIDTH = 400;
	private int DEFAULT_HEIGHT = 40;

	private JPanel codAerolineaPanel;
	private JPanel nomAerolineaPanel;
	private JPanel buttonPanel;

	private Aerolinea aerolinea = null;

	/**
	 * Metodo que inicia la construccion de ventanas.
	 */
	public AerolineaGUI() {
		construirGUI();
	}

	public void construirGUI() {
		setLayout(new GridLayout(1, 2));
		dibujarForm();
		iniciarTable();
		add(formPanel);
		add(scrollPane);
	}

	public void dibujarForm() {

		formPanel = new JPanel();
		formPanel.setBorder(BorderFactory.createTitledBorder("Formulario Aerolinea"));
		formPanel.setLayout(new BorderLayout());

		lblCodAerolinea = new JLabel("Codigo de la aerolinea");
		lblNomAerolinea = new JLabel("Nombre de la aerolinea");

		txtAerolineaCod = new JTextField(5);
		txtNomAerolinea = new JTextField(10);

		btnGuardarAerolinea = new JButton("A�adir Aerolinea");
		btnGuardarAerolinea.addActionListener(this);

		codAerolineaPanel = new JPanel();
		nomAerolineaPanel = new JPanel();
		buttonPanel = new JPanel();

		codAerolineaPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		codAerolineaPanel.setMaximumSize(codAerolineaPanel.getPreferredSize());
		codAerolineaPanel.setLayout(new FlowLayout());
		codAerolineaPanel.add(lblCodAerolinea);
		codAerolineaPanel.add(txtAerolineaCod);

		nomAerolineaPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		nomAerolineaPanel.setMaximumSize(nomAerolineaPanel.getPreferredSize());
		nomAerolineaPanel.setLayout(new FlowLayout());
		nomAerolineaPanel.add(lblNomAerolinea);
		nomAerolineaPanel.add(txtNomAerolinea);

		buttonPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		buttonPanel.setMaximumSize(buttonPanel.getPreferredSize());
		buttonPanel.setLayout(new FlowLayout());
		buttonPanel.add(btnGuardarAerolinea);

		mainBox = Box.createVerticalBox();
		mainBox.add(codAerolineaPanel);
		mainBox.add(nomAerolineaPanel);
		mainBox.add(buttonPanel);

		formPanel.add(mainBox, BorderLayout.CENTER);

	}

	private void iniciarTable() {
		Object columnNames[] = { "Codigo de la aerolinea", "Nombre de la Aerolinea" };
		tableModel = new DefaultTableModel(columnNames, 0);
		tablaAerolinea = new JTable(tableModel);
		tablaAerolinea.setBackground(Color.GRAY);
		scrollPane = new JScrollPane(tablaAerolinea);
		configTablaData();
	}

	private void configTablaData() {
		tableModel = (DefaultTableModel) tablaAerolinea.getModel();
		tableModel.setRowCount(0);

		LinkedHashMap<String, Aerolinea> list = Aux_Datos.Instanciar.getList(DataType.AEROLINEA);
		Iterator<Aerolinea> iterator = list.values().iterator();
		while (iterator.hasNext()) {
			Aerolinea aerolinea = iterator.next();
			Vector<Object> vector = returnObjectArray(aerolinea);
			tableModel.addRow(vector);
		}
		tablaAerolinea.repaint();
	}

	private Vector<Object> returnObjectArray(Aerolinea aerolinea2) {
		Vector<Object> vector = new Vector<>();
		vector.add(aerolinea2.getCodAerolinea());
		vector.add(aerolinea2.getNomAerolinea());
		return vector;
	}

	@Override
	public void notificar(Aerolinea model, OpType opType) {
		configTablaData();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		aerolinea = new Aerolinea();
		aerolinea.setCodAerolinea(txtAerolineaCod.getText());
		aerolinea.setNomAerolinea(txtNomAerolinea.getText());
		aerolinea.agregarObserver(this);

		if (e.getSource() == btnGuardarAerolinea) {
			String result = validarControles(Aux_Datos.OpType.INSERTAR);
			if (result != null) {
				mostrarError(result);
				return;
			} else {
				guardarRegistro(OpType.INSERTAR);
				return;
			}
		}

	}

	public String validarControles(OpType opType) {
		String codAerolinea = aerolinea.getCodAerolinea();
		String nomAerolinea = aerolinea.getNomAerolinea();

		if (codAerolinea.length() <= 0) {
			return "El codigo de la aerolinea no puede estar vacio.";
		}

		if (nomAerolinea.length() <= 0) {
			return "El nombre de la aerolinea no puede estar vacio.";
		}

		boolean existe = Aux_Datos.Instanciar.contieneKeys(codAerolinea, Aux_Datos.DataType.AEROLINEA);
		if (existe && opType == OpType.INSERTAR) {
			return "Ya hay una aerolinea existente, no pueden haber elementos repetidos";
		}

		return null;
	}

	public void guardarRegistro(OpType opType) {
		boolean seGuardo = Aux_Datos.Instanciar.agregarObject(aerolinea, aerolinea.getCodAerolinea(), DataType.AEROLINEA, opType);
		if (seGuardo) {
			JOptionPane.showMessageDialog(formPanel, "Data guardada", "CONTINUAR", JOptionPane.INFORMATION_MESSAGE);
			limpiarForm();
		} else {
			JOptionPane.showMessageDialog(formPanel, "No se ha podido guardar la data", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void limpiarForm() {
		txtAerolineaCod.setText(null);
		txtNomAerolinea.setText(null);
	}

	public void mostrarError(String message) {
		JOptionPane.showMessageDialog(formPanel, message, "Error de validacion", JOptionPane.ERROR_MESSAGE);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
	}

}