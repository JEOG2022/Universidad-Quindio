package GUI;


import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Clases.Aerolinea;
import Clases.Vuelo;
import metodos_Aux.Aux_Datos;
import metodos_Aux.IObserver;
import metodos_Aux.Aux_Datos.DataType;
import metodos_Aux.Aux_Datos.OpType;



public class VueloGUI extends JPanel implements ActionListener, IObserver<Vuelo> {

	private static final long serialVersionUID = 2892904376555547152L;
	private JPanel formPanel;
	private JTable tablaVuelo;
	private JScrollPane scrollPane;
	private DefaultTableModel tablaModel;
	private Box mainBox;

	private JLabel lblVueloID;
	private JLabel lblOrigen;
	private JLabel lblDestino;
	private JLabel lblDespegue;
	private JLabel lblAterrizaje;
	private JLabel lblAerolinea;

	private JTextField txtvueloID;
	private JTextField txtOrigen;
	private JTextField txtDestino;
	private JTextField txtDespegue;
	private JTextField txtAterrizaje;
	private JComboBox<String> cmbAerolinea;

	private JButton btnguardarVuelo;

	private int DEFAULT_WIDTH = 400;
	private int DEFAULT_HEIGHT = 40;

	private JPanel idPanel;
	private JPanel panelOrigen;
	private JPanel destinoPanel;
	private JPanel despeguePanel;
	private JPanel aterrizajePanel;
	private JPanel aerolineaPanel;
	private JPanel botonPanel;

	private Vuelo vuelo = null;

	/**
	 *  Metodo que inicia la construccion de ventanas..
	 */
	public VueloGUI() {
		construirGUI();
	}

	private void construirGUI() {
		setLayout(new GridLayout(1, 2));
		dibujarForm();
		iniciarTabla();
		add(formPanel);
		add(scrollPane);
//		En principio establece una ventana resolucion(850, 400);
	}

	private void dibujarForm() {
		formPanel = new JPanel();
		formPanel.setBorder(BorderFactory.createTitledBorder("Formulario"));
		formPanel.setLayout(new BorderLayout());

		lblVueloID = new JLabel("Numero de vuelo");
		lblOrigen = new JLabel("Origen");
		lblDestino = new JLabel("Destino");
		lblDespegue = new JLabel("H.Despegue");
		lblAterrizaje = new JLabel("H.Aterrizaje");
		lblAerolinea = new JLabel("Aerolinea");

		txtvueloID = new JTextField(10);
		txtOrigen = new JTextField(10);
		txtDestino = new JTextField(10);
		txtDespegue = new JTextField(10);
		txtAterrizaje = new JTextField(10);

		cmbAerolinea = new JComboBox<>();
		actualizarComboBox();

		btnguardarVuelo = new JButton("Agregar");
		btnguardarVuelo.addActionListener(this);

		idPanel = new JPanel();
		panelOrigen = new JPanel();
		destinoPanel = new JPanel();
		despeguePanel = new JPanel();
		aterrizajePanel = new JPanel();
		aerolineaPanel = new JPanel();
		botonPanel = new JPanel();

		idPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		idPanel.setMaximumSize(idPanel.getPreferredSize());
		idPanel.setLayout(new FlowLayout());
		idPanel.add(lblVueloID);
		idPanel.add(txtvueloID);

		panelOrigen.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		panelOrigen.setMaximumSize(panelOrigen.getPreferredSize());
		panelOrigen.setLayout(new FlowLayout());
		panelOrigen.add(lblOrigen);
		panelOrigen.add(txtOrigen);

		destinoPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		destinoPanel.setMaximumSize(destinoPanel.getPreferredSize());
		destinoPanel.setLayout(new FlowLayout());
		destinoPanel.add(lblDestino);
		destinoPanel.add(txtDestino);

		despeguePanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		despeguePanel.setMaximumSize(despeguePanel.getPreferredSize());
		despeguePanel.setLayout(new FlowLayout());
		despeguePanel.add(lblDespegue);
		despeguePanel.add(txtDespegue);

		aterrizajePanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		aterrizajePanel.setMaximumSize(aterrizajePanel.getPreferredSize());
		aterrizajePanel.setLayout(new FlowLayout());
		aterrizajePanel.add(lblAterrizaje);
		aterrizajePanel.add(txtAterrizaje);

		aerolineaPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		aerolineaPanel.setMaximumSize(aerolineaPanel.getPreferredSize());
		aerolineaPanel.setLayout(new FlowLayout());
		aerolineaPanel.add(lblAerolinea);
		aerolineaPanel.add(cmbAerolinea);

		botonPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		botonPanel.setMaximumSize(botonPanel.getPreferredSize());
		botonPanel.setLayout(new FlowLayout());
		botonPanel.add(btnguardarVuelo);
		botonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

		mainBox = Box.createVerticalBox();
		mainBox.add(idPanel);
		mainBox.add(panelOrigen);
		mainBox.add(destinoPanel);
		mainBox.add(despeguePanel);
		mainBox.add(aterrizajePanel);
		mainBox.add(aerolineaPanel);
		mainBox.add(botonPanel);

		formPanel.add(mainBox, BorderLayout.CENTER);

	}

	private void actualizarComboBox() {
		if (cmbAerolinea == null) {
			cmbAerolinea = new JComboBox<>();
		}

		LinkedHashMap<String, Aerolinea> airlineMap = Aux_Datos.Instanciar.getList(DataType.AEROLINEA);
		cmbAerolinea.removeAllItems();
		Iterator<Aerolinea> iterator = airlineMap.values().iterator();
		while (iterator.hasNext()) {
			Aerolinea aerolinea = iterator.next();
			cmbAerolinea.addItem(aerolinea.getNomAerolinea());
		}
	}

	private void iniciarTabla() {
		Object columnNames[] = { "ID DEL VUELO", "ORIGEN", "Destino", "H.DESPEGUE", "H ATERRIZAJE", "Aerolinea" };
		tablaModel = new DefaultTableModel(columnNames, 0);
		tablaVuelo = new JTable(tablaModel);
		scrollPane = new JScrollPane(tablaVuelo);
		configTablaData();
	}

	private void configTablaData() {
		tablaModel = (DefaultTableModel) tablaVuelo.getModel();
		tablaModel.setRowCount(0);

		LinkedHashMap<String, Vuelo> vueloMap = Aux_Datos.Instanciar.getList(DataType.VUELO);
		Iterator<Vuelo> iterator = vueloMap.values().iterator();
		while (iterator.hasNext()) {
			Vuelo vuelo = iterator.next();
			Vector<Object> vector = retornarObjectArray(vuelo);
			tablaModel.addRow(vector);
		}
		tablaVuelo.repaint();
	}

	private Vector<Object> retornarObjectArray(Vuelo vuelo2) {
		Vector<Object> vector = new Vector<>();
		vector.add(vuelo2.getVueloID());
		vector.add(vuelo2.getOrigenVuelo());
		vector.add(vuelo2.getDestinoVuelo());
		vector.add(vuelo2.getAterrizajeVuelo());
		vector.add(vuelo2.getDespegueVuelo());
		vector.add(vuelo2.getAerolinea().getNomAerolinea());
		return vector;
	}

	@Override
	public void notificar(Vuelo model, OpType opType) {
		configTablaData();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		vuelo = new Vuelo();
		vuelo.setVueloID(txtvueloID.getText());
		vuelo.setOrigenVuelo(txtOrigen.getText());
		vuelo.setDestinoVuelo(txtDestino.getText());
		vuelo.setDespegueVuelo(txtDespegue.getText());
		vuelo.setAterrizajeVuelo(txtAterrizaje.getText());
		int selectedAirlineIndex = cmbAerolinea.getSelectedIndex();
		Aerolinea aerolinea = (Aerolinea) Aux_Datos.Instanciar.getObjectByIndex(selectedAirlineIndex, DataType.AEROLINEA);
		vuelo.setAirline(aerolinea);
		vuelo.agregarObserver(this);

		if (e.getSource() == btnguardarVuelo) {
			String result = validarControles(Aux_Datos.OpType.INSERTAR);
			if (result != null) {
				mostrarError(result);
				return;
			} else {
				guardarAlm(OpType.INSERTAR);
				return;
			}
		}
	}

	public void guardarAlm(OpType opType) {
		boolean seGuardo = Aux_Datos.Instanciar.agregarObject(vuelo, vuelo.getVueloID(), DataType.VUELO, opType);
		if (seGuardo) {
			JOptionPane.showMessageDialog(formPanel, "Datos guardados", "HECHO", JOptionPane.INFORMATION_MESSAGE);
			limpiarForm();
		} else {
			JOptionPane.showMessageDialog(formPanel, "No se pudo guardar la data", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void mostrarError(String message) {
		JOptionPane.showMessageDialog(formPanel, message, "Error de validacion", JOptionPane.ERROR_MESSAGE);

	}

	public String validarControles(OpType opType) {
		String vueloID = vuelo.getVueloID();
		String vueloOrigen= vuelo.getOrigenVuelo();
		String vueloDestino = vuelo.getDestinoVuelo();
		String vueloAterrizaje = vuelo.getAterrizajeVuelo();
		String vueloDespegue = vuelo.getDespegueVuelo();
		Aerolinea CodAerolinea = vuelo.getAerolinea();

		if (vueloID.length() <= 0) {
			return "Este espacio debe ser llenado";
		}

		if (vueloOrigen.length() <= 0) {
			return "El origen no puede estar vacio.";
		}

		if (vueloDestino.length() <= 0) {
			return "El destino no puede estar vacio.";
		}

		if (vueloAterrizaje.length() <= 0) {
			return "Por favor ingresar datos del aterrizaje.";
		}

		if (vueloDespegue.length() <= 0) {
			return "Por favor ingresar datos del despegue.";
		}

		if (CodAerolinea.getCodAerolinea().length() <= 0) {
			return "Ingresar codigo de la aerolinea, por favor.";
		}

		boolean exists = Aux_Datos.Instanciar.contieneKeys(vueloID, Aux_Datos.DataType.VUELO);
		if (exists && opType == OpType.INSERTAR) {
			return "Vuelo ya existente en el sistema, No se permite a�adir datos repetidos.";
		}
		return null;
	}

	private void limpiarForm() {
		txtvueloID.setText(null);
		txtOrigen.setText(null);
		txtDestino.setText(null);
		txtDespegue.setText(null);
		txtAterrizaje.setText(null);
		cmbAerolinea.setSelectedIndex(0);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		actualizarComboBox();
	}

}
