package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import Clases.Pasajero;
import Clases.Pasajero.PASSENGER_CLASS;
import metodos_Aux.Aux_Datos;
import metodos_Aux.Aux_Datos.DataType;
import metodos_Aux.Aux_Datos.OpType;
import metodos_Aux.IObserver;



public class PasajeroGUI extends JPanel implements ActionListener, IObserver<Pasajero> {

	/**
	 * @author janus 
	 * La interfaz pasajero tiene la funcion de obtener los datos del pasajaero para
	 * posteriormente asignarlos al vuelo correspondiente.
	 */
	
	private static final long serialVersionUID = -8762527504926439254L;
	private JPanel formPanel;
	private JTable tablePasajero;
	private JScrollPane scrollPane;
	private DefaultTableModel tableModelo;
	private Box mainBox;

	private JLabel lblPasajeroID;
	private JLabel lblNomPasajero;
	private JLabel lblEdadPasajero;
	private JLabel lblDirPasajero;
	private JLabel lblPassangerClass;

	private JTextField txtPasajeroID;
	private JTextField txtNomPasajero;
	private JTextField txtEdadPasajero;
	private JTextField txtDireccionPasajero;
	private JComboBox<String> cmbPassengerClass;

	private JButton btnGuardarPasajero;
	private JButton btnBorrarPasajero;

	private int DEFAULT_WIDTH = 400;
	private int DEFAULT_HEIGHT = 40;

	private JPanel idPanel;
	private JPanel nomPanel;
	private JPanel edadPanel;
	private JPanel direccionPanel;
	private JPanel classPanel;
	private JPanel vueloPanel;
	private JPanel botonPanel;

	private Pasajero pasajero = null;

	/**
	 *  Metodo que inicia la construccion de ventanas..
	 */
	public PasajeroGUI() {
		construirGUI();
	}

	private void construirGUI() {
		setLayout(new GridLayout(1, 2));
		contornoForm();
		inicializarTabla();
		add(formPanel);
		add(scrollPane);
	}

	private void contornoForm() {
		formPanel = new JPanel();
		formPanel.setBorder(BorderFactory.createTitledBorder("Formulario Pasajeros"));
		formPanel.setLayout(new BorderLayout());

		lblPasajeroID = new JLabel("ID Pasajero");
		lblNomPasajero = new JLabel("Nombre");
		lblEdadPasajero = new JLabel("Edad");
		lblDirPasajero = new JLabel("Direccion");
		lblPassangerClass = new JLabel("Seleccionar clase");

		txtPasajeroID = new JTextField(10);
		txtNomPasajero = new JTextField(15);
		txtEdadPasajero = new JTextField(5);
		txtDireccionPasajero = new JTextField(15);

		cmbPassengerClass = new JComboBox<>();
		cmbPassengerClass.addItem("Economica");
		cmbPassengerClass.addItem("Business");

		btnGuardarPasajero = new JButton("A\u00F1adir");
		btnGuardarPasajero.addActionListener(this);
		btnBorrarPasajero = new JButton("Borrar");
		btnBorrarPasajero.addActionListener(this);

		idPanel = new JPanel();
		nomPanel = new JPanel();
		edadPanel = new JPanel();
		direccionPanel = new JPanel();
		classPanel = new JPanel();
		vueloPanel = new JPanel();
		botonPanel = new JPanel();

		idPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		idPanel.setMaximumSize(idPanel.getPreferredSize());
		idPanel.setLayout(new FlowLayout());
		idPanel.add(lblPasajeroID);
		idPanel.add(txtPasajeroID);

		nomPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		nomPanel.setMaximumSize(nomPanel.getPreferredSize());
		nomPanel.setLayout(new FlowLayout());
		nomPanel.add(lblNomPasajero);
		nomPanel.add(txtNomPasajero);

		edadPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		edadPanel.setMaximumSize(edadPanel.getPreferredSize());
		edadPanel.setLayout(new FlowLayout());
		edadPanel.add(lblEdadPasajero);
		edadPanel.add(txtEdadPasajero);

		direccionPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		direccionPanel.setMaximumSize(direccionPanel.getPreferredSize());
		direccionPanel.setLayout(new FlowLayout());
		direccionPanel.add(lblDirPasajero);
		direccionPanel.add(txtDireccionPasajero);

		classPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		classPanel.setMaximumSize(classPanel.getPreferredSize());
		classPanel.setLayout(new FlowLayout());
		classPanel.add(lblPassangerClass);
		classPanel.add(cmbPassengerClass);

		botonPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		botonPanel.setMaximumSize(botonPanel.getPreferredSize());
		botonPanel.setLayout(new FlowLayout());
		botonPanel.add(btnGuardarPasajero);
		botonPanel.add(btnBorrarPasajero);

		mainBox = Box.createVerticalBox();
		mainBox.add(idPanel);
		mainBox.add(nomPanel);
		mainBox.add(edadPanel);
		mainBox.add(direccionPanel);
		mainBox.add(classPanel);
		mainBox.add(vueloPanel);
		vueloPanel.setLayout(null);
		mainBox.add(botonPanel);

		formPanel.add(mainBox, BorderLayout.CENTER);
	}

	private void inicializarTabla() {
		Object columnNoms[] = { "ID", "Nombre", "Edad", "Direccion", "Clase" };
		tableModelo = new DefaultTableModel(columnNoms, 0);
		tablePasajero = new JTable(tableModelo);
		scrollPane = new JScrollPane(tablePasajero);
		configurarTablaData();
	}

	private void configurarTablaData() {
		tableModelo = (DefaultTableModel) tablePasajero.getModel();
		tableModelo.setRowCount(0);
		
		LinkedHashMap<String, Pasajero> pasajerosMap = Aux_Datos.Instanciar.getList(DataType.PASAJERO);
		Iterator<Pasajero> iterator = pasajerosMap.values().iterator();
		
		while (iterator.hasNext()) {
			Pasajero pasajero = iterator.next();
			Vector<Object> vector = returnarObjectArray(pasajero);
			tableModelo.addRow(vector);	
			
		}
		tablePasajero.repaint();
	}

	private Vector<Object> returnarObjectArray(Pasajero pasajero2) {
		Vector<Object> vector = new Vector<>();
		vector.add(pasajero2.getIDPasajero());
		vector.add(pasajero2.getNombrePersona());
		vector.add(pasajero2.getEdadPersona());
		vector.add(pasajero2.getDireccionPersona());
		vector.add(pasajero2.getPassengerClass());
		return vector;
	}

	
	@Override
	public void notificar(Pasajero model, OpType opType) {
		configurarTablaData();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String edadText = txtEdadPasajero.getText();
		int edad = 0;
		try {
			edad = Integer.parseInt(edadText);
		} catch (NumberFormatException e1) {
			mostrarError("Solo puede ingresar numeros.");
			return;
		}

		int indiceSeleccionClase = cmbPassengerClass.getSelectedIndex();
		PASSENGER_CLASS pClass = null;
		switch (indiceSeleccionClase) {
		case 0:
			pClass = PASSENGER_CLASS.ECONOMICA;
			break;
		case 1:
			pClass = PASSENGER_CLASS.BUSINESS;
			break;
		default:
			JOptionPane.showMessageDialog(null, "Seleccione una clase", "Error", JOptionPane.INFORMATION_MESSAGE);
			break;
		}

		pasajero = new Pasajero(txtNomPasajero.getText(), edad, txtDireccionPasajero.getText(),
				txtPasajeroID.getText());
		pasajero.setPassengerClass(pClass);
		pasajero.agregarObserver(this);

		if (e.getSource() == btnGuardarPasajero) {
			String result = validarControles(Aux_Datos.OpType.INSERTAR);
			if (result != null) {
				mostrarError(result);
				return;
			} else {
				boolean poderReservar = true;
				if (poderReservar) {
					guardarIng(OpType.INSERTAR);
				} else {
					mostrarError("Lo sentimos. Usted agrego mas del limite de reservas permitidas");
				}
				// retornar;
			}
		}

		if (e.getSource() == btnBorrarPasajero) {
			String result = validarControles(Aux_Datos.OpType.BORRAR);
			if (result != null) {
				mostrarError(result);
				return;
			} else {
				borrarRegistro();
				return;
			}
		}
	}

	public void guardarIng(OpType opType) {
		boolean guardado = Aux_Datos.Instanciar.agregarObject(pasajero, pasajero.getIDPasajero(), DataType.PASAJERO,
				opType);
		if (guardado) {
			JOptionPane.showMessageDialog(formPanel, "Guardado", "HECHO", JOptionPane.INFORMATION_MESSAGE);
			limpiarForm();
		} else {
			JOptionPane.showMessageDialog(formPanel, "No se pudo guardar la data", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void borrarRegistro() {
		boolean eliminado = Aux_Datos.Instanciar.eliminarObject(pasajero.getIDPasajero(), DataType.PASAJERO);
		if (eliminado) {
			JOptionPane.showMessageDialog(formPanel, "Data eliminada", "HECHO", JOptionPane.INFORMATION_MESSAGE);
			limpiarForm();
		} else {
			JOptionPane.showMessageDialog(formPanel, "No se pudo eliminarla data", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void limpiarForm() {
		txtPasajeroID.setText(null);
		txtNomPasajero.setText(null);
		txtEdadPasajero.setText(null);
		txtDireccionPasajero.setText(null);
		cmbPassengerClass.setSelectedIndex(0);
	}

	private void mostrarError(String message) {
		JOptionPane.showMessageDialog(formPanel, message, "Error de validacion", JOptionPane.ERROR_MESSAGE);
	}

	public String validarControles(OpType opType) {
		String pasajeroID = pasajero.getIDPasajero();
		String nomPasajero = pasajero.getNombrePersona();
		int edadPasajero = pasajero.getEdadPersona();
		String direccionPsj = pasajero.getDireccionPersona();
		PASSENGER_CLASS passengerClass = pasajero.getPassengerClass();

		if (pasajeroID.length() <= 0) {
			return "La ID NO puede estar vacia.";
		}

		if (nomPasajero.length() <= 0 && opType != OpType.BORRAR) {
			return "Debe ingresar el nombre del pasajero.";
		}

		if (edadPasajero < 1 && opType != OpType.BORRAR) {
			return "Edad ingresada incorrectamente";
		}

		if (direccionPsj.length() <= 0 && opType != OpType.BORRAR) {
			return "La direccion no puede estar vacia";
		}

		if (passengerClass.toString().length() <= 0) {
			return "Debe ingresar la clase del pasajero";
		}

		boolean existe = Aux_Datos.Instanciar.contieneKeys(pasajeroID, Aux_Datos.DataType.PASAJERO);
		if (existe && opType == OpType.INSERTAR) {
			return "Pasajero ya registrado en el sistema, no se permite elementos duplicados";
		}

		if (!existe && opType == OpType.BORRAR) {
			return "Lo sentimos, no se pudo guardar.";
		}

		return null;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
	}
}