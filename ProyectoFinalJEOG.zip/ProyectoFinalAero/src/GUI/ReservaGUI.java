package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Clases.Pasajero;
import Clases.Reservacion;
import Clases.Vuelo;
import metodos_Aux.Aux_Datos;
import metodos_Aux.Aux_Reservacion;
import metodos_Aux.IObserver;
import metodos_Aux.Aux_Datos.DataType;
import metodos_Aux.Aux_Datos.OpType;


public class ReservaGUI extends JPanel implements ActionListener, IObserver<Reservacion> {

	private static final long serialVersionUID = 2654771029234438507L;
	private JPanel formPanel;
	private JTable reservaTabla;
	private JScrollPane scrollPane;
	private DefaultTableModel modeloTabla;
	private Box mainBox;

	private JLabel lblVuelo;
	private JLabel lblPasajero;

	private JComboBox<String> cmbPasajero;
	private JComboBox<String> cmbVuelo;

	private JButton btnGuardarReserv;
	private JButton btnBorrarReserv;

	private int DEFAULT_WIDTH = 400;
	private int DEFAULT_HEIGHT = 40;

	private JPanel vueloPanel;
	private JPanel pasajeroPanel;
	private JPanel botonPanel;

	private Reservacion reservacion = null;

	/**
	 *  Metodo que inicia la construccion de ventanas.
	 */
	public ReservaGUI() {
		construirGUI();
	}

	private void construirGUI() {
		setLayout(new GridLayout(1, 2));
		dibujarForm();
		iniciarTabla();
		add(formPanel);
		add(scrollPane);
		setVisible(true);
	}

	private void dibujarForm() {
		formPanel = new JPanel();
		formPanel.setBorder(BorderFactory.createTitledBorder("Reservacion"));
		formPanel.setLayout(new BorderLayout());

		lblVuelo = new JLabel("Vuelo");
		lblPasajero = new JLabel("Pasajero");

		cmbVuelo = new JComboBox<>();
		cmbPasajero = new JComboBox<>();
		actualizarComboBox();

		btnGuardarReserv = new JButton("A\u00F1adir");
		btnGuardarReserv.addActionListener(this);
		btnBorrarReserv = new JButton("Borrar");
		btnBorrarReserv.addActionListener(this);

		vueloPanel = new JPanel();
		pasajeroPanel = new JPanel();
		botonPanel = new JPanel();

		vueloPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		vueloPanel.setMaximumSize(vueloPanel.getPreferredSize());
		vueloPanel.setLayout(new FlowLayout());
		vueloPanel.add(lblVuelo);
		vueloPanel.add(cmbVuelo);

		pasajeroPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		pasajeroPanel.setMaximumSize(pasajeroPanel.getPreferredSize());
		pasajeroPanel.setLayout(new FlowLayout());
		pasajeroPanel.add(lblPasajero);
		pasajeroPanel.add(cmbPasajero);

		botonPanel.setPreferredSize(new Dimension(DEFAULT_WIDTH, DEFAULT_HEIGHT));
		botonPanel.setMaximumSize(botonPanel.getPreferredSize());
		botonPanel.setLayout(new FlowLayout());
		botonPanel.add(btnGuardarReserv);
		botonPanel.add(btnBorrarReserv);

		mainBox = Box.createVerticalBox();
		mainBox.add(vueloPanel);
		mainBox.add(pasajeroPanel);
		mainBox.add(botonPanel);

		formPanel.add(mainBox, BorderLayout.CENTER);
	}

	private void actualizarComboBox() {
		if (cmbVuelo == null) {
			cmbVuelo = new JComboBox<>();
		}
		LinkedHashMap<String, Vuelo> vueloMap = Aux_Datos.Instanciar.getList(DataType.VUELO);
		cmbVuelo.removeAllItems();
		Iterator<Vuelo> vueloIterator = vueloMap.values().iterator();
		while (vueloIterator.hasNext()) {
			Vuelo vuelo = vueloIterator.next();
			cmbVuelo.addItem(vuelo.getVueloID());
		}

		if (cmbPasajero == null) {
			cmbPasajero = new JComboBox<>();
		}
		LinkedHashMap<String, Pasajero> pasajeroMap = Aux_Datos.Instanciar.getList(DataType.PASAJERO);			
		cmbPasajero.removeAllItems();
		Iterator<Pasajero> pasajeroIterator = pasajeroMap.values().iterator();
		while (pasajeroIterator.hasNext()) {
			Pasajero passenger = pasajeroIterator.next();
			cmbPasajero.addItem(passenger.getIDPasajero());
		}
	}

	private void iniciarTabla() {
		Object columnNoms[] = { "ID", "Pasajero", "Airbus" };
		modeloTabla = new DefaultTableModel(columnNoms, 0);
		reservaTabla = new JTable(modeloTabla);
		scrollPane = new JScrollPane(reservaTabla);
		configTablaData();
	}

	private void configTablaData() {
		modeloTabla = (DefaultTableModel) reservaTabla.getModel();
		modeloTabla.setRowCount(0);

		LinkedHashMap<String, Reservacion> reservacionMap = Aux_Datos.Instanciar.getList(DataType.RESERVACION);
		Iterator<Reservacion> iterator = reservacionMap.values().iterator();
		while (iterator.hasNext()) {
			Reservacion reservacion = iterator.next();
			Vector<Object> vector = retornarObjectArray(reservacion);
			modeloTabla.addRow(vector);
		}
		reservaTabla.repaint();
	}

	private Vector<Object> retornarObjectArray(Reservacion reserva2) {
		Vector<Object> vector = new Vector<>();
		vector.add(reserva2.getPasajero().getIDPasajero());
		vector.add(reserva2.getPasajero().getNombrePersona());
		vector.add(reserva2.getVuelo().getVueloID());
		return vector;
	}

	@Override
	public void notificar(Reservacion model, OpType opType) {
		configTablaData();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		reservacion = new Reservacion();

		int vueloSeleccionado = cmbVuelo.getSelectedIndex();
		Vuelo vuelo = (Vuelo) Aux_Datos.Instanciar.getObjectByIndex(vueloSeleccionado, DataType.VUELO);
		reservacion.setVuelo(vuelo);

		int pasajaeroSeleccionado = cmbPasajero.getSelectedIndex();
		Pasajero passenger = (Pasajero) Aux_Datos.Instanciar.getObjectByIndex(pasajaeroSeleccionado,
				DataType.PASAJERO);
		reservacion.setPasajero(passenger);

		reservacion.agregarObserver(this);

		if (e.getSource() == btnGuardarReserv) {
			String result = validarControles(Aux_Datos.OpType.INSERTAR);
			if (result != null) {
				mostrarError(result);
				return;
			} else {
				boolean noIngresada = Aux_Reservacion.bookingResolver(reservacion);
				if (noIngresada) {
					guardarAlm(OpType.INSERTAR);
				} else {
					mostrarError("ERROR, la reservacion fue ingresada incorrectamente.");
				}
				return;
			}
		}

		if (e.getSource() == btnBorrarReserv) {
			String result = validarControles(Aux_Datos.OpType.BORRAR);
			if (result != null) {
				mostrarError(result);
				return;
			} else {
				borrarAlm();
				configTablaData();
				return;
			}
		}
	}

	private void guardarAlm(OpType opType) {
		String key = reservacion.getPasajero().getIDPasajero() + ":"
				+ reservacion.getVuelo().getVueloID();
		boolean guardada = Aux_Datos.Instanciar.agregarObject(reservacion, key, DataType.RESERVACION, opType);
		if (guardada) {
			JOptionPane.showMessageDialog(formPanel, "Record Saved", "SUCCESS", JOptionPane.INFORMATION_MESSAGE);
			limpiarForm();
		} else {
			JOptionPane.showMessageDialog(formPanel, "Unable to save the record", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void borrarAlm() {
		String key = reservacion.getPasajero().getIDPasajero() + ":"
				+ reservacion.getVuelo().getVueloID();
		boolean eliminada = Aux_Datos.Instanciar.eliminarObject(key, DataType.RESERVACION);
		if (eliminada) {
			JOptionPane.showMessageDialog(formPanel, "Record Deleted", "SUCCESS", JOptionPane.INFORMATION_MESSAGE);
			limpiarForm();
		} else {
			JOptionPane.showMessageDialog(formPanel, "Unable to delete the record", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void mostrarError(String mensaje) {
		JOptionPane.showMessageDialog(formPanel, mensaje, "Validation Error", JOptionPane.ERROR_MESSAGE);
	}

	private String validarControles(OpType opType) {
		String vueloID = reservacion.getVuelo().getVueloID();
		String pasajeroID = reservacion.getPasajero().getIDPasajero();

		if (vueloID.length() <= 0) {
			return "Por favor, especificar identificacion del avion";
		}

		if (pasajeroID.length() <= 0) {
			return "La identificacion del pasajero no puede ir en blanco.";
		}

		String key = pasajeroID + ":" + vueloID;
		boolean exists = Aux_Datos.Instanciar.contieneKeys(key,Aux_Datos.DataType.RESERVACION);
		if (exists && opType == OpType.INSERTAR) {
			return "El pasajero ya esta agendado para este vuelo";
		}

		if (!exists && opType == OpType.BORRAR) {
			return "Lo sentimos. El agendamiento de este pasajero no existe en el sistema.";
		}

		return null;
	}

	private void limpiarForm() {
		cmbVuelo.setSelectedIndex(0);
		cmbPasajero.setSelectedIndex(0);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		actualizarComboBox();
	}

}