package Principal;

import javax.swing.JOptionPane;

import UI.ReservacionAerolineaUI;
import metodos_Aux.Aux_Archivos;
import UI.AUI;

public class MenuUI {

	public static void main(String[] args) {

		/**
		 * 
		 * Este menu de interfaz de usuario se realizo con el fin de chequear la manipulacion de datos y 
		 * su estructura en funcion a la interfaz grafica, como una forma de esqueleto, con el fin
		 * de corregir acciones en la interfaz grafica y observar si todos los metodos de guardado y obtencion de datos
		 * funcionan correctamente.
		 * 
		 */
		
		String[] opciones = { "Crear un nuevo archivo", "Cargar un archivo existente" };
		String mensaje = "Desea crear un nuevo archivo o cargar uno ya existente?";
		int opcionSeleccionada = JOptionPane.showOptionDialog(null, mensaje, "Elegir una opcion", JOptionPane.DEFAULT_OPTION,
				JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

		if (opcionSeleccionada == 1) {
			try {
				Aux_Archivos.deserialize();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Error recopilando archivos", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}

		AUI aReserv = new AUI();

		try {
			aReserv.displayMenu();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Aplicacion cancelada por el usuario");
		}

	}

}
