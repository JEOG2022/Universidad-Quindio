package Principal;

import javax.swing.JOptionPane;
import GUI.FormularioGUI;
import metodos_Aux.Aux_Archivos;
import metodos_Aux.Aux_Datos;
import Sistema_Embarque.EmbarqueGUI;

public class PrincipalGUI {

	public static void main(String[] args) {
		
		/**
		 * 
		 * La interfaz grafica de usuario, se dise�o de tal manera de emular una aplicacion de reservacion de vuelos.
		 *
		 */

		String[] opciones = { "Crear nuevo archivo", "Cargar un archivo existente" };
		String mensaje = "Te gustaria crear un nuevo archivo o cargar uno ya existente?";
		int opcionElegida = JOptionPane.showOptionDialog(null, mensaje, "Elegir opcion", JOptionPane.DEFAULT_OPTION,
				JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

		if (opcionElegida == 1) {
			try {
				Aux_Archivos.deserialize();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Error al recuperar los archvios", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}

		FormularioGUI ccgui = new FormularioGUI();
		ccgui.setVisible(true);
	}

}