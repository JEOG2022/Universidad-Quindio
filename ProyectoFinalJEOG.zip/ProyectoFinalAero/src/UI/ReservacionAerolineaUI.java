package UI;


import java.awt.HeadlessException;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.swing.JOptionPane;

import Clases.Aerolinea;
import Clases.Pasajero;
import Clases.Reservacion;
import Clases.Vuelo;
import Clases.Pasajero.PASSENGER_CLASS;
import metodos_Aux.Aux_Archivos;
import metodos_Aux.Aux_Datos;
import metodos_Aux.Aux_Reservacion;
import metodos_Aux.Aux_Datos.DataType;
import metodos_Aux.Aux_Datos.OpType;

public class ReservacionAerolineaUI {

	// A�adir aerolineas
	public void a�adirAerolinea(String codAerolinea, String nomAerolinea) {
		try {
			codAerolinea = JOptionPane.showInputDialog("Ingrese el codigo de la aerolinea");
			nomAerolinea = JOptionPane.showInputDialog("Ingrese el nombre de la aerolinea");

			while (true) {
				if (!Aux_Datos.Instanciar.contieneKeys(codAerolinea, DataType.AEROLINEA)) {
					Aerolinea aerolinea = new Aerolinea(codAerolinea, nomAerolinea);
					Aux_Datos.Instanciar.agregarObject(aerolinea, aerolinea.getCodAerolinea(), DataType.AEROLINEA, OpType.INSERTAR);
					break;
				}
				JOptionPane.showMessageDialog(null, "Aerolinea ya existente. No se puede agregar elementos duplicados",
						"ERROR", JOptionPane.ERROR_MESSAGE);
				break;
			}
		} catch (HeadlessException e) {
			e.printStackTrace();
		}
	}

	// Mostrar Aerolineas
	public void mostrarAerolineas() {
		LinkedHashMap<String, Aerolinea> aerolineaMap = Aux_Datos.Instanciar.getList(DataType.AEROLINEA);
		Iterator<Aerolinea> aerolineaIterator = aerolineaMap.values().iterator();
		while (aerolineaIterator.hasNext()) {
			Aerolinea aerolinea = aerolineaIterator.next();
			aerolinea.verDetalles();

		}
	}

	// Agregar vuelos
	public void a�adirVuelos(String vueloID, String origen, String destino, String despegue, String aterrizaje) {
		try {
			vueloID = JOptionPane.showInputDialog("Ingrese la flota del vuelo");
			origen = JOptionPane.showInputDialog("Ingrese origen del vuelo");
			destino = JOptionPane.showInputDialog("Ingrese el destino");
			despegue = JOptionPane.showInputDialog("Ingrese hora de despegue");
			aterrizaje = JOptionPane.showInputDialog("Ingrese hora de aterrizaje");
			String codAerolinea = JOptionPane.showInputDialog("Ingrese el codigo de la aerolinea");
			Aerolinea aerolinea = (Aerolinea) Aux_Datos.Instanciar.getObject(codAerolinea, DataType.AEROLINEA);

			while (true) {
				if (!Aux_Datos.Instanciar.contieneKeys(vueloID, DataType.VUELO)) {
					Vuelo vuelo = new Vuelo(vueloID, origen, destino, aterrizaje, despegue);
					Aux_Datos.Instanciar.agregarObject(vuelo, vueloID, DataType.VUELO, OpType.INSERTAR);
					vuelo.setAirline(aerolinea);
					break;
				}
				JOptionPane.showMessageDialog(null, "Vuelo ya existente. No se permite a�adir vuelos duplicados",
						"ERROR", JOptionPane.ERROR_MESSAGE);
				break;
			}
		} catch (HeadlessException e) {
			e.printStackTrace();
		}
	}

	// Mostrar los vuelos
	public void mostrarVuelos() {
		LinkedHashMap<String, Vuelo> vueloMap = Aux_Datos.Instanciar.getList(DataType.VUELO);
		Iterator<Vuelo> vueloIterator = vueloMap.values().iterator();
		while (vueloIterator.hasNext()) {
			Vuelo vuelo = vueloIterator.next();
		    vuelo.mostrarDetalles();
		}
	}

	// Agregar pasajeros
	public void a�adirPasaj(String nombre, int edad, String direccion, String pasajeroID) {
		try {
			pasajeroID = JOptionPane.showInputDialog("Ingrese el id del pasajero en cuestion");
			nombre = JOptionPane.showInputDialog("Ingrese el nombre del pasajero");
			edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad del pasajero"));
			direccion = JOptionPane.showInputDialog("Ingrese la direccion del pasajero");
			String pClase = JOptionPane.showInputDialog("Seleccione la clase del vuelo: 1 si es economica o 2 si es Business");
			PASSENGER_CLASS passengerClass = null;
			int eleccion = 0;
			eleccion = Integer.parseInt(pClase);

			switch (eleccion) {
			case 1:
				passengerClass = PASSENGER_CLASS.ECONOMICA;
				break;
			case 2:
				passengerClass = PASSENGER_CLASS.BUSINESS;
				break;
			}

			while (true) {
				if (!Aux_Datos.Instanciar.contieneKeys(pasajeroID, DataType.PASAJERO)) {
					Pasajero pasajero = new Pasajero(nombre, edad, direccion, pasajeroID);
					pasajero.setPassengerClass(passengerClass);
					Aux_Datos.Instanciar.agregarObject(pasajero, pasajero.getIDPasajero(), DataType.PASAJERO,
							OpType.INSERTAR);
					break;
				}
				JOptionPane.showMessageDialog(null, "Pasajero ya existente en el sistema, no se permite agregar",
						"ERROR", JOptionPane.ERROR_MESSAGE);
				break;
			}
		} catch (HeadlessException e) {
			e.printStackTrace();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
	}

	// Mostrar todos los pasajeros
	public void mostrarPasaj() {
		LinkedHashMap<String, Pasajero> passengerMap = Aux_Datos.Instanciar.getList(DataType.PASAJERO);
		Iterator<Pasajero> pasajeroIterator = passengerMap.values().iterator();
		while (pasajeroIterator.hasNext()) {
			Pasajero pasajero= pasajeroIterator.next();
			pasajero.mostrarDetalles();
		}
	}

	public void eliminarPasaj() {
		String pasajeroID = JOptionPane.showInputDialog("Ingrese la ID del pasajero a eliminar");
		while (true) {
			if (Aux_Datos.Instanciar.contieneKeys(pasajeroID, DataType.PASAJERO)) {
				boolean seElimino = Aux_Datos.Instanciar.eliminarObject(pasajeroID, DataType.PASAJERO);
				if (seElimino) {
					JOptionPane.showMessageDialog(null, "Pasajero eliminado", "HECHO",
							JOptionPane.INFORMATION_MESSAGE);
					break;
				} else {
					JOptionPane.showMessageDialog(null, "No se ha podido eliminar el pasajero", "ERROR",
							JOptionPane.ERROR_MESSAGE);
					break;
				}
			}
			JOptionPane.showMessageDialog(null, "No hay data del pasajero en el sistema", "ERROR",
					JOptionPane.ERROR_MESSAGE);
			break;
		}

	}

	// Add Bookings
	public void a�adirReserv(String pasajeroID, String vueloID) {
		a�adirReservas(pasajeroID, vueloID);
	}

	// Add Bookings
	public void a�adirReservas(String pasajeroID, String vueloID) {
		try {
			pasajeroID = JOptionPane.showInputDialog("Ingrese el numero de identificacion del pasajero");
			vueloID = JOptionPane.showInputDialog("Ingrese el ");
			Pasajero pasajero = (Pasajero) Aux_Datos.Instanciar.getObject(pasajeroID, DataType.PASAJERO);
			Vuelo vuelo = (Vuelo) Aux_Datos.Instanciar.getObject(vueloID, DataType.VUELO);

			String key = pasajeroID + ":" + vueloID;
			while (true) {
				if (!Aux_Datos.Instanciar.contieneKeys(key, DataType.PASAJERO)) {
					Reservacion reservacion = new Reservacion();
					reservacion.setPasajero(pasajero);
					reservacion.setVuelo(vuelo);
					boolean bookingPossible = Aux_Reservacion.bookingResolver(reservacion);
					if (bookingPossible) {
						Aux_Datos.Instanciar.agregarObject(reservacion, key, DataType.PASAJERO, OpType.INSERTAR);
						break;
					} else {
						JOptionPane.showMessageDialog(null,
								"Lo sentimos, ha revasado el limite de pasajeros permitidos en el vuelo", "ERROR",
								JOptionPane.ERROR_MESSAGE);
						break;
					}

				}
				JOptionPane.showMessageDialog(null, "El pasajero ya fue registrado en este vuelo", "ERROR",
						JOptionPane.ERROR_MESSAGE);
				break;
			}
		} catch (HeadlessException e) {
			e.printStackTrace();
		}
	}

	// Lista de reservas
	public void mostrarListaReserv() {
		LinkedHashMap<String, Reservacion> reservacionMap = Aux_Datos.Instanciar.getList(DataType.PASAJERO);
		Iterator<Reservacion> reservacionIterator = reservacionMap.values().iterator();
		while (reservacionIterator.hasNext()) {
			Reservacion reservacion = reservacionIterator.next();
			reservacion.mostrarDetalles();
		}
	}

	// Metodo para eliminar reservas
	public void eliminarReservas() {
		String pasajeroID = JOptionPane.showInputDialog("Ingrese la id del pasajero en cuestion");
		String vueloID = JOptionPane.showInputDialog("Ingrese la ID del vuelo");

		String key = pasajeroID + ":" + vueloID;
		while (true) {
			if (Aux_Datos.Instanciar.contieneKeys(key, DataType.PASAJERO)) {
				boolean seElimino = Aux_Datos.Instanciar.eliminarObject(key, DataType.RESERVACION);
				if (seElimino) {
					JOptionPane.showMessageDialog(null, "Data eliminada", "HECHO", JOptionPane.INFORMATION_MESSAGE);
					break;
				} else {
					JOptionPane.showMessageDialog(null, "No se ha podido eliminar la data", "ERROR",
							JOptionPane.ERROR_MESSAGE);
					break;
				}
			}
			JOptionPane.showMessageDialog(null, "No hay archivos relacionados con la data de las reservaciones", "ERROR",
					JOptionPane.ERROR_MESSAGE);
			break;
		}
	}

	// Almacenar toda la informacion 
	public void serializeData() {
		boolean result = Aux_Archivos.serialize();
		if (result) {
			JOptionPane.showMessageDialog(null, "Guardado correctamente", "HECHO", JOptionPane.INFORMATION_MESSAGE);
		} else {
			JOptionPane.showMessageDialog(null, "Error al restaurar data", "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

}