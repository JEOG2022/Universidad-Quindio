package UI;

import javax.swing.JOptionPane;

public class AUI {

	ReservacionAerolineaUI ars = new ReservacionAerolineaUI();

	public void displayMenu() {
		String output, casos;
		int eleccion = 0;
		do {
			output = getDisplayMessage();
			casos = JOptionPane.showInputDialog(output);
			try {
				eleccion = Integer.parseInt(casos);
				ejecutar(eleccion);
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Dato invalido", "WARNING", JOptionPane.WARNING_MESSAGE);
			}
		} while (eleccion != 12);
	}

	private void ejecutar(int eleccion) {

		switch (eleccion) {
		case 1:
			String codAerolinea = null;
			String nomAerolinea = null;
			ars.a�adirAerolinea(codAerolinea, nomAerolinea);
			break;
		case 2:
			ars.mostrarAerolineas();
			break;
		case 3:
			String vueloID = null;
			String origen = null;
			String destino = null;
			String despegue = null;
			String aterrizaje = null;
			ars.a�adirVuelos(vueloID, origen, destino, despegue, aterrizaje);
			break;
		case 4:
			ars.mostrarVuelos();
			break;
		case 5:
			String pasajeroID = null;
			String nombre = null;
			int edad = 0;
			String direccion = null;
			ars.a�adirPasaj(nombre, edad, direccion, pasajeroID);
			break;
		case 6:
			ars.mostrarPasaj();
			break;
		case 7:
			ars.eliminarPasaj();
			break;
		case 8:
			pasajeroID = null;
			origen = null;
			ars.a�adirReservas(pasajeroID, origen);
			break;
		case 9:
			ars.mostrarListaReserv();
			break;
		case 10:
			ars.eliminarReservas();
			break;
		case 11:
			ars.serializeData();
			break;
		case 12:
			System.exit(0);
			break;
		default:
			eleccionIncorrecta();
		}

	}

	private void eleccionIncorrecta() {
		String error;
		error = "Eleccion no permitida.";
		JOptionPane.showMessageDialog(null, error, "Error", JOptionPane.ERROR_MESSAGE);
	}

	private String getDisplayMessage() {
		String output;

		output = "Sistema de reserva de vuelos \n";
		output = output + "Seleccione una opcion \n\n";
		output = output + "1 - Crear y a�adir una aerolinea \n";
		output = output + "2 - Mostrar todas las aerolineas \n";
		output = output + "3 - Crear y a�adir un vuelo \n";
		output = output + "4 - Mostrar todos los vuelos \n";
		output = output + "5 - Agregar pasajeros \n";
		output = output + "6 - Mostrar pasajeros \n";
		output = output + "7 - Eliminar pasajeros \n";
		output = output + "8 - Pasaporte para un vuelo \n";
		output = output + "9 - Mostrar pasaporte \n";
		output = output + "10 - Eliminar Data \n";
		output = output + "11 - Guardar la data \n";
		output = output + "12 - Salir";

		return output;
	}

}