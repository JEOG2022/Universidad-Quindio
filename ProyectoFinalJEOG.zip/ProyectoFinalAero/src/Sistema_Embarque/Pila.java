package Sistema_Embarque;

public class Pila {
	   private ListaLigada pila;
	   
	   public Pila(){
	       pila = new ListaLigada();
	   }
	   
	   public void push(Object dato){
	       pila.insertarPrimero(dato);
	   }
	   
	   public Object pop(){
	       Object Dato = pila.getElementos()[0];
	       pila.eliminarPrimero();
	       return Dato;
	   }
	   
	   public Object peek(){
	       return pila.getElementos()[0];
	   }
	   
	   public int size(){
	       return pila.getTamanio();
	   }
	   
	   public Object[] getElementos(){
	       return pila.getElementos();
	   }
}
