package Sistema_Embarque;

public class ListaLigada {
    
    private Nodo primero,ultimo;  
    private int tamanio;
    
      public ListaLigada(){
        ultimo = primero = null;
        tamanio = 0;
    }
    
  
    public void insertarPrimero(Object valor){
        if(tamanio == 0){
            primero = new Nodo(valor,null);
            ultimo = primero;
            tamanio++;
        }
        else{
            Nodo temporal = primero;
            primero = new Nodo(valor,temporal);
            tamanio++;
        }
    }
    
    
    public void insertarUltimo(Object valor){
        if(tamanio == 0){
            primero = new Nodo(valor,null);
            ultimo = primero;
            tamanio++;
        }
        else{
            Nodo temporal = ultimo;
            ultimo = new Nodo(valor, null);
            temporal.setSiguiente(ultimo);
            tamanio++;
        }
    }
    
 
    public void eliminarPrimero(){
        if(tamanio == 0)return;
        Nodo temporal = primero;
        temporal = primero.getSiguiente();
        primero = null;
        primero = temporal;
        tamanio--;
    }
    
    public void eliminarUltimo(){
        if(tamanio == 0)return;
        if(tamanio == 1){
            ultimo = primero = null;
            tamanio = 0;
            return;
        }
        Nodo temporal = primero;
        while(temporal.getSiguiente() != ultimo){
            temporal = temporal.getSiguiente();
        }
        temporal.setSiguiente(null);
        ultimo = temporal;
        tamanio--;
    }
    
   
    public int getTamanio(){
        return tamanio;
    }
    
    
    public Object[] getElementos(){
        if(tamanio == 0)return new Object[0];
        Object[] elementos = new Object[tamanio];
        int i = 0;
        Nodo temporal = primero;
        while(temporal != null){
            System.out.print(temporal.getValor().toString()+"  ");
            elementos[i++] = temporal.getValor();
            temporal = temporal.getSiguiente();
        }
        System.out.println("");
        return elementos;
    }
    
    public static void main(String[] args) {
        ListaLigada lista = new ListaLigada();
        lista.insertarPrimero(1);
    }
}
