package Sistema_Embarque;



import javax.swing.JOptionPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;

public class EmbarqueGUI extends javax.swing.JFrame {

    Pila pila;
    Cola cola;
    public EmbarqueGUI() {
        initComponents();
        pila = new Pila();
        cola = new Cola();
    }

    /**
     * Este metodo iniciar la estructura del form.
     */
    @SuppressWarnings("unchecked")

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        elementos = new javax.swing.JList();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        elementos2 = new javax.swing.JList();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton3.setText("Ultimo carro en la fila");
        jButton9 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestion embarque");
        setResizable(false);

        jPanel1.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel1.setFont(new java.awt.Font("Tempus Sans ITC", 1, 18)); 
        jLabel1.setText("Embarque de equipaje");

        elementos.setName("elementos"); 
        jScrollPane1.setRowHeaderView(elementos);

        jLabel2.setFont(new java.awt.Font("Tempus Sans ITC", 1, 12)); 
        jLabel2.setText("Estacionamiento North");

        jButton1.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); 
        jButton1.setText("Agregar Carro");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); 
        jButton2.setText("Desembotellar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); 
        jButton5.setText("Carros aparcados");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tempus Sans ITC", 1, 12));
        jLabel3.setText("Estacionamiento South");

        elementos2.setName("elementos"); 
        jScrollPane2.setViewportView(elementos2);

        jButton6.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); 
        jButton6.setText("Agregar carro");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); 
        jButton7.setText("Desembotellar");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); 
        jButton8.setText("Carros aparcados");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Tempus Sans ITC", 1, 14)); 
        jButton9.setText("Ultimo carro en la fila");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGap(345)
        			.addComponent(jLabel1)
        			.addContainerGap(334, Short.MAX_VALUE))
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 137, GroupLayout.PREFERRED_SIZE)
        					.addGap(18)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        						.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)
        						.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)
        						.addComponent(jButton5, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)
        						.addComponent(jButton3, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)))
        				.addComponent(jLabel2))
        			.addPreferredGap(ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        				.addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 137, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel3))
        			.addGap(18)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(jButton6, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jButton7, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jButton8, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jButton9, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE))
        			.addGap(81))
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel2)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING, false)
        						.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 387, GroupLayout.PREFERRED_SIZE)
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(jButton3, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        							.addComponent(jButton5, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
        							.addGap(82))))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(jLabel1)
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addComponent(jLabel3)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        						.addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 387, GroupLayout.PREFERRED_SIZE)
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addComponent(jButton6, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(jButton7, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(jButton9, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
        							.addGap(18)
        							.addComponent(jButton8, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)))))
        			.addGap(0, 11, Short.MAX_VALUE))
        );
        jPanel1.setLayout(jPanel1Layout);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(26)
        			.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(47, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(Alignment.TRAILING, layout.createSequentialGroup()
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        			.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        );
        getContentPane().setLayout(layout);

        pack();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        try{
            Object valor = JOptionPane.showInputDialog("Ingresa el peso de la carga del carro");
            if(valor == null)return;
            pila.push(valor);
            elementos.setListData(pila.getElementos());

        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al aparcar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        if(pila.size()==0){
            JOptionPane.showMessageDialog(this, "No hay coches aparcados en el sector North");
            return;
        }
        try{
            Object dato = pila.pop();
            elementos.setListData(pila.getElementos());
            JOptionPane.showMessageDialog(this, "Carro en salida: "+dato.toString());
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "El carro no pudo salir de la fila", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
        JOptionPane.showMessageDialog(this,"Hay un total de: "+pila.size() + "carros en zona de embarque en el sector North.");
    }

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
        try{
            Object valor = JOptionPane.showInputDialog("Ingrese el peso de la carga del carro");
            if(valor == null)return;
            cola.encolar(valor);
            elementos2.setListData(cola.getElementos());
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al apacar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
        if(cola.size()==0){
            JOptionPane.showMessageDialog(this, "No hay carros estacionados en el sector South");
            return;
        }
        try{
            Object dato = cola.desencolar();
            elementos2.setListData(cola.getElementos());
            JOptionPane.showMessageDialog(this, "Carro en salida: "+dato.toString());
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al salir de la fila", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
        JOptionPane.showMessageDialog(this,"Hay un total de : "+cola.size() + "carros en zona de embarque en el sector South.");
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
        if(pila.size()==0){
            JOptionPane.showMessageDialog(this, "No hay carros en zona de embarque");
            return;
        }
        try{
            Object dato = pila.peek();
            JOptionPane.showMessageDialog(this, "Carro: "+dato.toString());
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al ingresar carro", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
        if(cola.size()==0){
            JOptionPane.showMessageDialog(this, "No hay carros en zona de embarque");
            return;
        }
        try{
            Object dato = cola.frente();
            JOptionPane.showMessageDialog(this, "Carro: "+dato.toString());
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al ingresar carro", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    	/**
    	 * Esta CRUD fue realizada bajo el look and feel "Nimbus" que proporciona
    	 * un tipo de apariencia distinto a la ventana pero lastimosamente se probo en un computador
    	 * (no mio) con version JAVA SE 6 y cambia el tipo de apariencia a uno generico. 
    	 * por lo que se recomiendo utilizar un RUNTIME de versiones mas recientes.
    	 **/
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmbarqueGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmbarqueGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmbarqueGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmbarqueGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

      /**
       * Este metodo viene por defecto en el source usando el Swing, y funciona para dar visibilidad a la ventana desde
       * la ventana principal del proyecto.
       */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmbarqueGUI().setVisible(true);
            }
        });
    }

    private javax.swing.JList elementos;
    private javax.swing.JList elementos2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
}
