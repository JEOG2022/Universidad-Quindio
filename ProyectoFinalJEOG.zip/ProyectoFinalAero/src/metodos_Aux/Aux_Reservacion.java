package metodos_Aux;


import java.util.Iterator;
import java.util.LinkedHashMap;

import Clases.Aerolinea;
import Clases.Pasajero;
import Clases.Reservacion;
import Clases.Pasajero.PASSENGER_CLASS;
import metodos_Aux.Aux_Datos.DataType;


public class Aux_Reservacion {

	public static boolean bookingResolver(Reservacion reservacion) {

		Aerolinea aerolinea = reservacion.getVuelo().getAerolinea();
				

		Pasajero pasajero = reservacion.getPasajero();
				

		PASSENGER_CLASS clasepasajero = pasajero.getPassengerClass();
				

		int reservasMaximasPermitidas = 0;

		switch (clasepasajero) {
		case ECONOMICA:
			reservasMaximasPermitidas = 138;
			break;
		case BUSINESS:
			reservasMaximasPermitidas = 12;
			break;
		default:
			return false;
		}

		LinkedHashMap<String, Reservacion> reservacionMap = Aux_Datos.Instanciar.getList(DataType.RESERVACION);
		Iterator<Reservacion> iterator = reservacionMap.values().iterator();
		int reservacionesHastaAhora = 0;

		while (iterator.hasNext()) {
			Reservacion reserva = iterator.next();
			if (reserva.getVuelo().getAerolinea().getCodAerolinea().equalsIgnoreCase(aerolinea.getCodAerolinea())
					&& reserva.getPasajero().getIDPasajero().equalsIgnoreCase(pasajero.getIDPasajero())) {
				reservacionesHastaAhora++;
			}
			if (reservacionesHastaAhora >= reservasMaximasPermitidas) {
				return false;
			}
		}
		return true;
	}

}
