package metodos_Aux;

import java.util.ArrayList;

import metodos_Aux.Aux_Datos.OpType;

public class Observable<T> implements IObservable<T> {

	private ArrayList<IObserver<T>> observers = new ArrayList<>();

	public void agregarObserver(IObserver<T> observer) {
		synchronized (observers) {
			observers.add(observer);
		}
	}

	public void eliminarObserver(IObserver<T> observer) {
		synchronized (observers) {
			observers.remove(observer);
		}
	}

	public void notificarObservers(final T t, OpType opType) {
		synchronized (observers) {
			for (IObserver<T> iObserver : observers) {
				iObserver.notificar(t, opType);
			}
		}
	}

}
