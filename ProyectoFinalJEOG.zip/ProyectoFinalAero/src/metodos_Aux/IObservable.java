package metodos_Aux;

public interface IObservable<T> {
	void agregarObserver(IObserver<T> observer);
	void eliminarObserver(IObserver<T> observer);
}
