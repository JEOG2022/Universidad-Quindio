package metodos_Aux;


import java.util.LinkedHashMap;

import Clases.Aerolinea;
import Clases.Pasajero;
import Clases.Reservacion;
import Clases.Vuelo;
import Clases.Pasajero.PASSENGER_CLASS;
import Clases.Equipaje;
import Clases.Equipaje.TIENE_MASCOTA;

public class Aux_Datos {

	private LinkedHashMap<String, Aerolinea> listaAerolinea;
	private LinkedHashMap<String, Vuelo> listaVuelos;
	private LinkedHashMap<String, Pasajero> listaPasajeros;
	private LinkedHashMap<String, Reservacion> listaReservacion;
	private LinkedHashMap<String, Equipaje> listaEquipaje;

	@SuppressWarnings("rawtypes")
	private LinkedHashMap hashMap;

	public static final Aux_Datos Instanciar = new Aux_Datos();

	public enum DataType {
		AEROLINEA, VUELO, PASAJERO, RESERVACION,EQUIPAJE;
	}

	public enum OpType {
		INSERTAR, BORRAR;
	}

	public Aux_Datos() {
		listaAerolinea = new LinkedHashMap<>();
		listaVuelos= new LinkedHashMap<>();
		listaPasajeros = new LinkedHashMap<>();
		listaReservacion = new LinkedHashMap<>();
		listaEquipaje = new LinkedHashMap<>();
	}

	@SuppressWarnings("unchecked")
	public <T> LinkedHashMap<String, T> getList(DataType dataType) {
		switch (dataType) {
		case AEROLINEA:
			return (LinkedHashMap<String, T>) listaAerolinea;
		case VUELO:
			return (LinkedHashMap<String, T>) listaVuelos;
		case PASAJERO:
			return (LinkedHashMap<String, T>) listaPasajeros;
		case RESERVACION:
			return (LinkedHashMap<String, T>) listaReservacion;
		case EQUIPAJE:
			return (LinkedHashMap<String, T>) listaEquipaje;
			
		default:
			return null;
		}
	}

	public Object getObject(String key, DataType dataType) {
		boolean exists = contieneKeys(key, dataType);
		if (exists) {
			seleccionarDataType(dataType);
			if (hashMap != null) {
				return hashMap.get(key);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	public Object getObjectByIndex(int index, DataType dataType) {
		seleccionarDataType(dataType);
		if (hashMap != null) {
			try {
				return hashMap.values().toArray()[index];
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		} else {
			return null;
		}
	}

	public boolean contieneKeys(String key, DataType dataType) {
		seleccionarDataType(dataType);
		if (hashMap != null && hashMap.containsKey(key)) {
			return true;
		} else {
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public boolean agregarObject(Object object, String key, DataType dataType, OpType opType) {
		seleccionarDataType(dataType);
		hashMap.put(key, object);
		notificar(object, dataType, OpType.INSERTAR);
		return true;
	}

	public boolean eliminarObject(String key, DataType dataType) {
		seleccionarDataType(dataType);
		Object object = hashMap.get(key);
		hashMap.remove(key);
		notificar(object, dataType, OpType.BORRAR);
		return true;
	}

	public void notificar(Object object, DataType dataType, OpType opType) {
		switch (dataType) {
		case AEROLINEA:
			Aerolinea aerolinea = (Aerolinea) object;
			aerolinea.actualizar(opType);
			break;
		case VUELO:
			Vuelo vuelo = (Vuelo) object;
			vuelo.actualizar(opType);
			break;
		case PASAJERO:
			Pasajero pasajero = (Pasajero) object;
			pasajero.actualizar(opType);	
			break;
		case RESERVACION:
			Reservacion reservacion = (Reservacion) object;
			reservacion.update(opType);
			break;
		case EQUIPAJE:
			Equipaje equipaje = (Equipaje) object;
			equipaje.update(opType);
			break;
			
		default:
			break;
		}
	}

	public void seleccionarDataType(DataType dataType) {
		hashMap = null;
		switch (dataType) {
		case AEROLINEA:
			hashMap = listaAerolinea;
			break;
		case VUELO:
			hashMap = listaVuelos;
			break;
		case PASAJERO:
			hashMap = listaPasajeros;
			break;
		case RESERVACION:
			hashMap = listaReservacion;
			break;
		case EQUIPAJE:
			hashMap = listaEquipaje;
			break;
			
		default:
			hashMap = null;
		}
	}

}
