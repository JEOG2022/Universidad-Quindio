package metodos_Aux;

import metodos_Aux.Aux_Datos.OpType;
public interface IObserver<T> {
	void notificar(T model, OpType opType);
}
