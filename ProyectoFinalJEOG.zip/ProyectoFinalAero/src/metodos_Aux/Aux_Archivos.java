package metodos_Aux;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JOptionPane;

import Clases.Aerolinea;
import Clases.Equipaje;
import Clases.Pasajero;
import Clases.Reservacion;
import Clases.Vuelo;
import Clases.Pasajero.PASSENGER_CLASS;
import metodos_Aux.Aux_Datos.DataType;
import metodos_Aux.Aux_Datos.OpType;

import java.util.Set;

public class Aux_Archivos {

	//En la ruta base debe colocar la direccion de la carpeta donde quiere que se guarden los datos.
	public static final String RUTA_BASE = "C:\\Users\\janus\\Desktop\\Reservas Caribbean Airlines";

	/**
	 * 
	 * @author janus 
	 * Los metodos auxiliadores fueron implementados con el fin de tener una gestion mas sencilla
	 * en el flujo de datos de las clases, de igual manera en este mismo paquete se encuentran los metodos utilizados
	 * en la serializacion y deserealizacion de los datos ingresados por el usuario en cuestion.
	 * 
	 */
	
	public static boolean serialize() {

		try {

			File direccionGuardado = new File(RUTA_BASE);
			if (!direccionGuardado.exists()) {
				direccionGuardado.mkdirs();
			}

			// Serializacion de los datos de la aerolinea
			File file = new File(direccionGuardado + "//aerolinea.txt");
			FileOutputStream fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(Aux_Datos.Instanciar.getList(DataType.AEROLINEA));
			oos.close();
			fos.close();

			// Serializacion de los vuelos
			file = new File(direccionGuardado + "//vuelo.txt");
			fos = new FileOutputStream(file);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(Aux_Datos.Instanciar.getList(DataType.VUELO));
			oos.close();
			fos.close();

			// Serializacion de los pasajeros
			file = new File(direccionGuardado + "//pasajero.txt");
			fos = new FileOutputStream(file);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(Aux_Datos.Instanciar.getList(DataType.PASAJERO));
			oos.close();
			fos.close();
			
			//Serializacion del equipaje
			file = new File(direccionGuardado + "//equipaje.txt");
			fos = new FileOutputStream(file);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(Aux_Datos.Instanciar.getList(DataType.EQUIPAJE));
			oos.close();
			fos.close();

			// Serializacion de las reservaciones
			file = new File(direccionGuardado + "//reservacion.txt");
			fos = new FileOutputStream(file);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(Aux_Datos.Instanciar.getList(DataType.RESERVACION));
			oos.close();
			fos.close();

			return true;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	public static boolean deserialize() {
		deserializeAerolinea();		
		deserializeVuelo();
		deserializePasajero();
		deserializeReservacion();
		deserializeEquipaje();
		return true;
	}

	// Metodo deserializador del la data de la aerolinea
	@SuppressWarnings("unchecked")
	public static boolean deserializeAerolinea() {
		LinkedHashMap<String, Aerolinea> aerolineaHashMap = new LinkedHashMap<>();
		try {
			FileInputStream fis = new FileInputStream(RUTA_BASE + "//aerolinea.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			aerolineaHashMap = (LinkedHashMap<String, Aerolinea>) ois.readObject();
			ois.close();
			fis.close();
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Archivos de aerolinea no encontrada", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Clase aerolinea no encontrada", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Error IO", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		}

		Set<Entry<String, Aerolinea>> aerolineaSet = aerolineaHashMap.entrySet();
		Iterator<Entry<String, Aerolinea>> iterator = aerolineaSet.iterator();
		@SuppressWarnings("unused")
		int cont = 0;
		while (iterator.hasNext()) {
			Map.Entry<String, Aerolinea> mapEntry = (Map.Entry<String, Aerolinea>) iterator.next();
			Aux_Datos.Instanciar.agregarObject(mapEntry.getValue(), mapEntry.getKey(), DataType.AEROLINEA, OpType.INSERTAR);
			cont++;
		}
		return true;
	}
	
	// Metodo deserializador del la data del equipaje
		@SuppressWarnings("unchecked")
		public static boolean deserializeEquipaje() {
			LinkedHashMap<String, Equipaje> equipajeHashMap = new LinkedHashMap<>();
			try {
				FileInputStream fis = new FileInputStream(RUTA_BASE + "//equipaje.txt");
				ObjectInputStream ois = new ObjectInputStream(fis);
				equipajeHashMap = (LinkedHashMap<String, Equipaje>) ois.readObject();
				ois.close();
				fis.close();
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog(null, "Archivos de equipaje no encontrados", "ERROR", JOptionPane.ERROR_MESSAGE);
				return false;
			} catch (ClassNotFoundException e) {
				JOptionPane.showMessageDialog(null, "Clase Equipaje no encontrada", "ERROR", JOptionPane.ERROR_MESSAGE);
				return false;
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Error IO", "ERROR", JOptionPane.ERROR_MESSAGE);
				return false;
			}

			Set<Entry<String, Equipaje>> equipajeSet = equipajeHashMap.entrySet();
			Iterator<Entry<String, Equipaje>> iterator = equipajeSet.iterator();
			@SuppressWarnings("unused")
			int cont = 0;
			while (iterator.hasNext()) {
				Map.Entry<String, Equipaje> mapEntry = (Map.Entry<String, Equipaje>) iterator.next();
				Aux_Datos.Instanciar.agregarObject(mapEntry.getValue(), mapEntry.getKey(), DataType.EQUIPAJE, OpType.INSERTAR);
				cont ++;
			}
			return true;
		}

	// Metodo deserializador del la data del vuelo
	@SuppressWarnings("unchecked")
	public static boolean deserializeVuelo() {
		LinkedHashMap<String, Vuelo> vueloHashMap = new LinkedHashMap<>();
		try {
			FileInputStream fis = new FileInputStream(RUTA_BASE + "//vuelo.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			vueloHashMap = (LinkedHashMap<String, Vuelo>) ois.readObject();
			ois.close();
			fis.close();
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null, "archivo VUELO no encontrado", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Clase no encontrada", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "I/O Error operacional", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		}

		Set<Entry<String, Vuelo>> vueloSet = vueloHashMap.entrySet();
		Iterator<Entry<String, Vuelo>> iterator = vueloSet.iterator();
		@SuppressWarnings("unused")
		int cont = 0;
		while (iterator.hasNext()) {
			Map.Entry<String, Vuelo> mapEntry = (Map.Entry<String, Vuelo>) iterator.next();
			Aux_Datos.Instanciar.agregarObject(mapEntry.getValue(), mapEntry.getKey(), DataType.VUELO, OpType.INSERTAR);
			cont++;
		}
		return true;
	}

	// Metodo deserializador del la data del pasajero
	@SuppressWarnings("unchecked")
	public static boolean deserializePasajero() {
		LinkedHashMap<String, Pasajero> pasajeroHashMap = new LinkedHashMap<>();
		try {
			FileInputStream fis = new FileInputStream(RUTA_BASE + "//pasajero.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			pasajeroHashMap = (LinkedHashMap<String, Pasajero>) ois.readObject();
			ois.close();
			fis.close();
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null, "archivo PASAJERO no encontrado", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Clase no encontrada", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "I/O Error operacional", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		}

		Set<Entry<String, Pasajero>> pasajeroSet = pasajeroHashMap.entrySet();
		Iterator<Entry<String, Pasajero>> iterator = pasajeroSet.iterator();
		@SuppressWarnings("unused")
		int cont = 0;
		while (iterator.hasNext()) {
			Map.Entry<String, Pasajero> mapEntry = (Map.Entry<String, Pasajero>) iterator.next();
			Aux_Datos.Instanciar.agregarObject(mapEntry.getValue(), (String) mapEntry.getKey(), DataType.PASAJERO,
					OpType.INSERTAR);
			cont++;
		}
		return true;
	}

	// Metodo deserializador del la data de la reservacion
	@SuppressWarnings("unchecked")
	public static boolean deserializeReservacion() {
		LinkedHashMap<String, Reservacion> reservasHashMap = new LinkedHashMap<>();
		try {
			FileInputStream fis = new FileInputStream(RUTA_BASE + "//reservacion.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			reservasHashMap = (LinkedHashMap<String, Reservacion>) ois.readObject();
			ois.close();
			fis.close();
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(null, "El archivo RESERVACION no se ha encontrado", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (ClassNotFoundException e) {
			JOptionPane.showMessageDialog(null, "Clase reserva no encontrado", "ERROR", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "I/O Error operacional", "ERROR", JOptionPane.ERROR_MESSAGE);
			return false;
		}

		Set<Entry<String, Reservacion>> seteoReserv = reservasHashMap.entrySet();
		Iterator<Entry<String, Reservacion>> iterator = seteoReserv.iterator();
		@SuppressWarnings("unused")
		int cont = 0;
		while (iterator.hasNext()) {
			Map.Entry<String, Reservacion> mapEntry = (Map.Entry<String, Reservacion>) iterator.next();
			Aux_Datos.Instanciar.agregarObject(mapEntry.getValue(), mapEntry.getKey(), DataType.RESERVACION,
					OpType.INSERTAR);
			cont++;
		}
		return true;
	}

}