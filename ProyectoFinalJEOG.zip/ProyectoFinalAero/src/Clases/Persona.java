package Clases;

import java.io.Serializable;

public abstract class Persona implements Serializable {

	private static final long serialVersionUID = 2461332992458003662L;
	private String nombrePersona;
	private int edadPersona;
	private String direccionPersona;
	protected String idPersona;



	public Persona(String nombrePersona, int edadPersona, String direccionPersona, String idPersona) {
		setNombrePersona(nombrePersona);
		setEdadPersona(edadPersona);
		setDireccionPersona(direccionPersona);
		setIdPersona(idPersona);
	}

	@Override
	public String toString() {
		String output;
		output = "Nombre de la persona: " + this.nombrePersona + "\nEdad: " + this.edadPersona + "\nDireccion: " + this.direccionPersona;
		return output;
	}

	public String getNombrePersona() {
		return nombrePersona;
	}

	public void setNombrePersona(String nombrePersona) {
		this.nombrePersona= nombrePersona;
	}

	public int getEdadPersona() {
		return edadPersona;
	}

	public void setEdadPersona(int edadPersona) {
		this.edadPersona = edadPersona;
	}

	public String getDireccionPersona() {
		return direccionPersona;
	}

	public void setDireccionPersona(String direccionPersona) {
		this.direccionPersona = direccionPersona;
	}

	public String getIdPersona() {
		return idPersona;
	}

	public void setIdPersona(String idPersona) {
		this.idPersona = idPersona;
	}

	
	
}