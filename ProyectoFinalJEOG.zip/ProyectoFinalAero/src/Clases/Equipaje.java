package Clases;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

import javax.swing.JOptionPane;



import metodos_Aux.IObservable;
import metodos_Aux.IObserver;
import metodos_Aux.Aux_Datos.OpType;

public class Equipaje extends Persona implements IObservable<Equipaje>, Serializable {

	private static final long serialVersionUID = -3867014842913870195L;
	private String etiquetaEp; 
	private int pesoMale;
	private ArrayList<IObserver<Equipaje>> observers = new ArrayList<>();
	

	
	public static enum TIENE_MASCOTA {
		SI, NO;
	}
	


	public Equipaje(String nombrePersona, int edadPersona, String direccionPersona, String idPersona, String etiquetaEp,
			int pesoMale, TIENE_MASCOTA mascotaEquipaje) {
		super(nombrePersona, edadPersona, direccionPersona, idPersona);
		this.etiquetaEp = etiquetaEp;
		this.pesoMale = pesoMale;
		this.mascotaEquipaje = mascotaEquipaje;
	}

	private TIENE_MASCOTA mascotaEquipaje;
	
	public Equipaje(String idPersona, String nombrePersona, String etiquetaEp, int pesoMale) {
		super(idPersona, pesoMale, etiquetaEp, nombrePersona);

		this.etiquetaEp=etiquetaEp;
		this.pesoMale = pesoMale;
		this.mascotaEquipaje = mascotaEquipaje;
	}

	@Override
	public String toString() {
		String output;
		output = super.toString();
		output = output + "\nDetalles del equipaje: " + this.etiquetaEp + "\nPeso neto de la maleta: " + this.pesoMale;
		return output;
	}
	
	public void displayDetails() {
		String output;
		output = toString();
		JOptionPane.showMessageDialog(null, output, "Detalles del equipaje", JOptionPane.INFORMATION_MESSAGE);
	}

	public String getEtiquetaEp() {
		return this.etiquetaEp;
	}

	public void setEtiquetaEp(String etiquetaEp) {
		this.etiquetaEp = etiquetaEp;
	}
	
	public int getPesoMale() {
		return this.pesoMale;
	}

	public void setPesoMale(int pesoMale) {
		this.pesoMale = pesoMale;
	}


	public TIENE_MASCOTA getMascotaEquipaje() {
		return mascotaEquipaje;
	}

	public void setMascotaEquipaje(TIENE_MASCOTA mascotaEquipaje) {
		this.mascotaEquipaje = mascotaEquipaje;
	}


	public void eliminarObserver(IObserver<Equipaje> observer) {
		synchronized (observers) {
			observers.remove(observer);
		}
	}

	public void update(OpType opType) {
		notificarObservers(this, opType);
	}

	protected void notificarObservers(final Equipaje tempEquipaje, OpType opType) {
		synchronized (observers) {
			for (IObserver<Equipaje> iObserver : observers) {
				iObserver.notificar(tempEquipaje, opType);
			}
		}
	
}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mascotaEquipaje== null) ? 0 : idPersona.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Equipaje other = (Equipaje) obj;
		return Objects.equals(etiquetaEp, other.etiquetaEp) && mascotaEquipaje == other.mascotaEquipaje
				&& Objects.equals(observers, other.observers) && pesoMale == other.pesoMale;
	}

	@Override
	public void agregarObserver(IObserver<Equipaje> equipajeGUI) {
		synchronized (observers) {
			observers.add(equipajeGUI);
		
	}
	
	
}
}





