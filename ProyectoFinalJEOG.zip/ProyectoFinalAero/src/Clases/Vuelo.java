package Clases;

import java.io.Serializable;

import javax.swing.JOptionPane;

import metodos_Aux.Aux_Datos;
import metodos_Aux.Observable;
import metodos_Aux.Aux_Datos.DataType;
import metodos_Aux.Aux_Datos.OpType;


public class Vuelo extends Observable<Vuelo> implements Serializable {

	private static final long serialVersionUID = 5893757679759603805L;
	private String vueloID;
	private String origenVuelo;
	private String destinoVuelo;
	private String despegueVuelo;
	private String aterrizajeVuelo;
	private String codAerolinea;

	public Vuelo() {
	}

	public Vuelo(String vueloID, String origenVuelo, String destinoVuelo, String despegueVuelo,
			String aterrizajeVuelo) {
		setVueloID(vueloID);
		setOrigenVuelo(origenVuelo);
		setDestinoVuelo(destinoVuelo);
		setDespegueVuelo(despegueVuelo);
		setAterrizajeVuelo(aterrizajeVuelo);
	}

	@Override
	public String toString() {
		String output;
		output = "Nombre de la aerolinea: " + getAerolinea().getNomAerolinea();
		output = output + "\nID del Vuelo: " + this.vueloID + "\nOrigen: " + this.origenVuelo + "\nDestino del vuelo: "
				+ this.destinoVuelo;
		output = output + "\nTiempo de despegue: " + this.despegueVuelo + "\nTiempo de llegada: " + this.aterrizajeVuelo;
		return output;
	}

	public void mostrarDetalles() {
		String output;
		output = toString();
		JOptionPane.showMessageDialog(null, output, "Detalles del vuelo: ", JOptionPane.INFORMATION_MESSAGE);
	}

	public String getVueloID() {
		return this.vueloID;
	}

	public void setVueloID(String vueloID) {
		this.vueloID = vueloID;
	}

	public String getOrigenVuelo() {
		return this.origenVuelo;
	}

	public void setOrigenVuelo(String origenVuelo) {
		this.origenVuelo = origenVuelo;
	}

	public String getDestinoVuelo() {
		return this.destinoVuelo;
	}

	public void setDestinoVuelo(String destinoVuelo) {
		this.destinoVuelo = destinoVuelo;
}

	public String getDespegueVuelo() {
		return this.despegueVuelo;
	}

	public void setDespegueVuelo(String despegueVuelo) {
		this.despegueVuelo = despegueVuelo;
	}

	public String getAterrizajeVuelo() {
		return this.aterrizajeVuelo;
	}

	public void setAterrizajeVuelo(String aterrizajeVuelo) {
		this.aterrizajeVuelo = aterrizajeVuelo;
	}

	public Aerolinea getAerolinea() {
		return (Aerolinea) Aux_Datos.Instanciar.getObject(this.codAerolinea, DataType.AEROLINEA);
	}

	public void setAirline(Aerolinea aerolinea) {
		this.codAerolinea = aerolinea.getCodAerolinea();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vueloID == null) ? 0 : vueloID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Vuelo))
			return false;
		Vuelo other = (Vuelo) obj;
		if (vueloID == null) {
			if (other.vueloID != null)
				return false;
		} else if (!vueloID.equals(other.vueloID))
			return false;
		return true;
	}

	public void actualizar(OpType opType) {
		notificarObservers(this, opType);
	}

}