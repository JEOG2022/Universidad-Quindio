package Clases;

import java.io.Serializable;

import javax.swing.JOptionPane;

import metodos_Aux.Observable;
import metodos_Aux.Aux_Datos.OpType;



public class Aerolinea extends Observable<Aerolinea> implements Serializable {

	private static final long serialVersionUID = 1260217919517302563L;
	private String codAerolinea;
	private String nomAerolinea;

	public Aerolinea() {
	}

	public Aerolinea(String codAerolinea, String nomAerolinea) {
		setCodAerolinea(codAerolinea);
		setNomAerolinea(nomAerolinea);
	}


	@Override
	public String toString() {
		return codAerolinea + ": " + nomAerolinea;
	}
 
	
	public void verDetalles() {
		String output;
		output = toString();
		JOptionPane.showMessageDialog(null, output, "Detalles de la Aerolinea: ", JOptionPane.INFORMATION_MESSAGE);
	}


	public String getCodAerolinea() {
		return codAerolinea;
	}

	public void setCodAerolinea(String codAerolinea) {
		this.codAerolinea = codAerolinea;
	}

	public String getNomAerolinea() {
		return nomAerolinea;
	}

	public void setNomAerolinea(String nomAerolinea) {
		this.nomAerolinea = nomAerolinea;
	}

	public void actualizar(OpType opType) {
		notificarObservers(this, opType);
	}

}
