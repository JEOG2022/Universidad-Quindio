package Clases;

import java.io.Serializable;
import javax.swing.JOptionPane;

import metodos_Aux.Observable;
import metodos_Aux.Aux_Datos.OpType;



public class Reservacion extends Observable<Reservacion> implements Serializable {

	private static final long serialVersionUID = 5930832207488694177L;
	private Pasajero pasajero;
	private Vuelo vuelo;

	public Reservacion() {
	}

	public String toString() {
		String output;
		output = "ID del pasajero: " + pasajero.getIDPasajero() + "\nNombre del pasajero: "
				+ pasajero.getNombrePersona() + "\nID vuelo: " + vuelo.getVueloID();
		return output;
	}

	public void mostrarDetalles() {
		String output;
		output = toString();
		JOptionPane.showMessageDialog(null, output, "Detalles de reservacion", JOptionPane.INFORMATION_MESSAGE);
	}

	public Pasajero getPasajero() {
		return this.pasajero;
	}

	public void setPasajero(Pasajero pasajero) {
		this.pasajero = pasajero;
	}

	public Vuelo getVuelo() {
		return this.vuelo;
	}

	public void setVuelo(Vuelo vuelo) {
		this.vuelo = vuelo;
	}

	public void update(OpType opType) {
		notificarObservers(this, opType);
	}

}